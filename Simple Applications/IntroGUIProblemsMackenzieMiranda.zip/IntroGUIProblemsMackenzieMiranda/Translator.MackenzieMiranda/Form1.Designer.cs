﻿namespace Translator.MackenzieMiranda
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Spanishbutton = new System.Windows.Forms.Button();
            this.GermanButton = new System.Windows.Forms.Button();
            this.FrenchButton = new System.Windows.Forms.Button();
            this.InstructionLabel = new System.Windows.Forms.Label();
            this.TranslationLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Spanishbutton
            // 
            this.Spanishbutton.Location = new System.Drawing.Point(12, 171);
            this.Spanishbutton.Name = "Spanishbutton";
            this.Spanishbutton.Size = new System.Drawing.Size(75, 23);
            this.Spanishbutton.TabIndex = 0;
            this.Spanishbutton.Text = "Spanish";
            this.Spanishbutton.UseVisualStyleBackColor = true;
            this.Spanishbutton.Click += new System.EventHandler(this.Spanishbutton_Click);
            // 
            // GermanButton
            // 
            this.GermanButton.Location = new System.Drawing.Point(118, 171);
            this.GermanButton.Name = "GermanButton";
            this.GermanButton.Size = new System.Drawing.Size(75, 23);
            this.GermanButton.TabIndex = 1;
            this.GermanButton.Text = "German";
            this.GermanButton.UseVisualStyleBackColor = true;
            this.GermanButton.Click += new System.EventHandler(this.GermanButton_Click);
            // 
            // FrenchButton
            // 
            this.FrenchButton.Location = new System.Drawing.Point(223, 171);
            this.FrenchButton.Name = "FrenchButton";
            this.FrenchButton.Size = new System.Drawing.Size(75, 23);
            this.FrenchButton.TabIndex = 2;
            this.FrenchButton.Text = "French";
            this.FrenchButton.UseVisualStyleBackColor = true;
            this.FrenchButton.Click += new System.EventHandler(this.FrenchButton_Click);
            // 
            // InstructionLabel
            // 
            this.InstructionLabel.AutoSize = true;
            this.InstructionLabel.Location = new System.Drawing.Point(31, 24);
            this.InstructionLabel.Name = "InstructionLabel";
            this.InstructionLabel.Size = new System.Drawing.Size(230, 26);
            this.InstructionLabel.TabIndex = 3;
            this.InstructionLabel.Text = "Click a language and I will say nice to meet you\r\n\r\n";
            // 
            // TranslationLabel
            // 
            this.TranslationLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TranslationLabel.Location = new System.Drawing.Point(31, 86);
            this.TranslationLabel.Name = "TranslationLabel";
            this.TranslationLabel.Size = new System.Drawing.Size(256, 33);
            this.TranslationLabel.TabIndex = 4;
            this.TranslationLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(331, 235);
            this.Controls.Add(this.TranslationLabel);
            this.Controls.Add(this.InstructionLabel);
            this.Controls.Add(this.FrenchButton);
            this.Controls.Add(this.GermanButton);
            this.Controls.Add(this.Spanishbutton);
            this.Name = "Form1";
            this.Text = "Language Translator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Spanishbutton;
        private System.Windows.Forms.Button GermanButton;
        private System.Windows.Forms.Button FrenchButton;
        private System.Windows.Forms.Label InstructionLabel;
        private System.Windows.Forms.Label TranslationLabel;
    }
}

