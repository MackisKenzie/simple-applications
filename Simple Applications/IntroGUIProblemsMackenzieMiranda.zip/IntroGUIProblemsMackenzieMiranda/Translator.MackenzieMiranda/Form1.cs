﻿//Author: Mackenzie Miranda
//Student ID:
//Date:6/12/23
//Goal: the goal is to translate words in different language
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Translator.MackenzieMiranda
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Spanishbutton_Click(object sender, System.EventArgs e)
        {
            TranslationLabel.Text = "Encantada de conocerte";
            //translating spanish into box
        }

        private void GermanButton_Click(object sender, System.EventArgs e)
        {
            TranslationLabel.Text = "Schön, dich kennenzulernen";
            //translating german into box
        }

        private void FrenchButton_Click(object sender, System.EventArgs e)
        {
            TranslationLabel.Text = "ravi de vous rencontrer";
            //translating french into box
        }
    }
}