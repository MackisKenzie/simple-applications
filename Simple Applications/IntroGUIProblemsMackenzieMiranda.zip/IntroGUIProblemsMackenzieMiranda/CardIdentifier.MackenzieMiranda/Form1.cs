﻿//Author: Mackenzie Miranda
//ID: 
//date:6/12/23
//Goal: Display text based on which card is clicked
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CardIdentifier.MackenzieMiranda
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void aceofdiamonds_Click(object sender, EventArgs e)
        {
            descriptionlabel.Text = "Ace of Diamonds";
            //sending ace of diamonds into description box when clicking on the card
        }

        private void kingofspades_Click(object sender, EventArgs e)
        {
            descriptionlabel.Text = "King of Spades";
            //sending king of spades into description box when clicking on the card
        }

        private void queenofdiamonds_Click(object sender, EventArgs e)
        {
            descriptionlabel.Text = "Queen of Diamonds";
            //sending queen of diamonds into description box when clicking on the card
        }

        private void Jackofclubs_Click(object sender, EventArgs e)
        {
            descriptionlabel.Text = "Jack of clubs";
            //sending jack of clubs to the description box when clicking on the card
        }
    }
}
