﻿namespace CardIdentifier.MackenzieMiranda
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.aceofdiamonds = new System.Windows.Forms.PictureBox();
            this.kingofspades = new System.Windows.Forms.PictureBox();
            this.queenofdiamonds = new System.Windows.Forms.PictureBox();
            this.Jackofclubs = new System.Windows.Forms.PictureBox();
            this.instructionlabel = new System.Windows.Forms.Label();
            this.descriptionlabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.aceofdiamonds)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingofspades)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.queenofdiamonds)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Jackofclubs)).BeginInit();
            this.SuspendLayout();
            // 
            // aceofdiamonds
            // 
            this.aceofdiamonds.Image = ((System.Drawing.Image)(resources.GetObject("aceofdiamonds.Image")));
            this.aceofdiamonds.Location = new System.Drawing.Point(12, 79);
            this.aceofdiamonds.Name = "aceofdiamonds";
            this.aceofdiamonds.Size = new System.Drawing.Size(87, 116);
            this.aceofdiamonds.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.aceofdiamonds.TabIndex = 1;
            this.aceofdiamonds.TabStop = false;
            this.aceofdiamonds.Click += new System.EventHandler(this.aceofdiamonds_Click);
            // 
            // kingofspades
            // 
            this.kingofspades.Image = ((System.Drawing.Image)(resources.GetObject("kingofspades.Image")));
            this.kingofspades.Location = new System.Drawing.Point(105, 79);
            this.kingofspades.Name = "kingofspades";
            this.kingofspades.Size = new System.Drawing.Size(87, 116);
            this.kingofspades.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.kingofspades.TabIndex = 3;
            this.kingofspades.TabStop = false;
            this.kingofspades.Click += new System.EventHandler(this.kingofspades_Click);
            // 
            // queenofdiamonds
            // 
            this.queenofdiamonds.Image = ((System.Drawing.Image)(resources.GetObject("queenofdiamonds.Image")));
            this.queenofdiamonds.Location = new System.Drawing.Point(198, 79);
            this.queenofdiamonds.Name = "queenofdiamonds";
            this.queenofdiamonds.Size = new System.Drawing.Size(87, 116);
            this.queenofdiamonds.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.queenofdiamonds.TabIndex = 4;
            this.queenofdiamonds.TabStop = false;
            this.queenofdiamonds.Click += new System.EventHandler(this.queenofdiamonds_Click);
            // 
            // Jackofclubs
            // 
            this.Jackofclubs.Image = ((System.Drawing.Image)(resources.GetObject("Jackofclubs.Image")));
            this.Jackofclubs.Location = new System.Drawing.Point(291, 79);
            this.Jackofclubs.Name = "Jackofclubs";
            this.Jackofclubs.Size = new System.Drawing.Size(87, 116);
            this.Jackofclubs.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Jackofclubs.TabIndex = 5;
            this.Jackofclubs.TabStop = false;
            this.Jackofclubs.Click += new System.EventHandler(this.Jackofclubs_Click);
            // 
            // instructionlabel
            // 
            this.instructionlabel.AutoSize = true;
            this.instructionlabel.Location = new System.Drawing.Point(122, 37);
            this.instructionlabel.Name = "instructionlabel";
            this.instructionlabel.Size = new System.Drawing.Size(152, 26);
            this.instructionlabel.TabIndex = 6;
            this.instructionlabel.Text = "Click on a card to see its name\r\n\r\n";
            // 
            // descriptionlabel
            // 
            this.descriptionlabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.descriptionlabel.Location = new System.Drawing.Point(60, 198);
            this.descriptionlabel.Name = "descriptionlabel";
            this.descriptionlabel.Size = new System.Drawing.Size(265, 27);
            this.descriptionlabel.TabIndex = 7;
            this.descriptionlabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(391, 235);
            this.Controls.Add(this.descriptionlabel);
            this.Controls.Add(this.instructionlabel);
            this.Controls.Add(this.Jackofclubs);
            this.Controls.Add(this.queenofdiamonds);
            this.Controls.Add(this.kingofspades);
            this.Controls.Add(this.aceofdiamonds);
            this.Name = "Form1";
            this.Text = "CardIdentifier";
            ((System.ComponentModel.ISupportInitialize)(this.aceofdiamonds)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingofspades)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.queenofdiamonds)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Jackofclubs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox aceofdiamonds;
        private System.Windows.Forms.PictureBox kingofspades;
        private System.Windows.Forms.PictureBox queenofdiamonds;
        private System.Windows.Forms.PictureBox Jackofclubs;
        private System.Windows.Forms.Label instructionlabel;
        private System.Windows.Forms.Label descriptionlabel;
    }
}

