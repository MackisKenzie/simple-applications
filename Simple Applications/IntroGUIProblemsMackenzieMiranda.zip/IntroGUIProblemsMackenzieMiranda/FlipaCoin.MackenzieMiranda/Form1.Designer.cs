﻿namespace FlipaCoin.MackenzieMiranda
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.coinflipbutton = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.headspicturebox = new System.Windows.Forms.PictureBox();
            this.tailspicturebox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.headspicturebox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tailspicturebox)).BeginInit();
            this.SuspendLayout();
            // 
            // coinflipbutton
            // 
            this.coinflipbutton.Location = new System.Drawing.Point(60, 274);
            this.coinflipbutton.Name = "coinflipbutton";
            this.coinflipbutton.Size = new System.Drawing.Size(75, 23);
            this.coinflipbutton.TabIndex = 0;
            this.coinflipbutton.Text = "Flip a coin";
            this.coinflipbutton.UseVisualStyleBackColor = true;
            this.coinflipbutton.Click += new System.EventHandler(this.coinflipbutton_Click);
            // 
            // exit
            // 
            this.exit.Location = new System.Drawing.Point(154, 274);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(75, 23);
            this.exit.TabIndex = 1;
            this.exit.Text = "Exit";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // headspicturebox
            // 
            this.headspicturebox.Image = ((System.Drawing.Image)(resources.GetObject("headspicturebox.Image")));
            this.headspicturebox.Location = new System.Drawing.Point(21, 43);
            this.headspicturebox.Name = "headspicturebox";
            this.headspicturebox.Size = new System.Drawing.Size(241, 215);
            this.headspicturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.headspicturebox.TabIndex = 2;
            this.headspicturebox.TabStop = false;
            // 
            // tailspicturebox
            // 
            this.tailspicturebox.Image = ((System.Drawing.Image)(resources.GetObject("tailspicturebox.Image")));
            this.tailspicturebox.Location = new System.Drawing.Point(21, 43);
            this.tailspicturebox.Name = "tailspicturebox";
            this.tailspicturebox.Size = new System.Drawing.Size(241, 215);
            this.tailspicturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.tailspicturebox.TabIndex = 3;
            this.tailspicturebox.TabStop = false;
            this.tailspicturebox.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(285, 309);
            this.Controls.Add(this.tailspicturebox);
            this.Controls.Add(this.headspicturebox);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.coinflipbutton);
            this.Name = "Form1";
            this.Text = "Coin Flipper";
            ((System.ComponentModel.ISupportInitialize)(this.headspicturebox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tailspicturebox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button coinflipbutton;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.PictureBox headspicturebox;
        private System.Windows.Forms.PictureBox tailspicturebox;
    }
}

