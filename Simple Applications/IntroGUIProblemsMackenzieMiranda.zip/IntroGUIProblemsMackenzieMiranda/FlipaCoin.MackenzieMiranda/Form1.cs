﻿// Author: Mackenzie Miranda
// ID:
// DATE: 6/12/23
// Goal: The goal of this application is to flip a coin
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlipaCoin.MackenzieMiranda
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void coinflipbutton_Click(object sender, EventArgs e)
        {
            // what makes it indicate which side is up
            int sideup;

            // Creates a Random object
            Random rand = new Random();

            // get a random number between 0 and 1
            // 0 means tails and 1 means heads
            sideup = rand.Next(2);

            // displays which side is up
            if (sideup == 0)
            {

                // shows tails as the side up
                tailspicturebox.Visible = true;
                headspicturebox.Visible = false;
            }
            else

            // shows heads as the side up
            { headspicturebox.Visible = true;
                tailspicturebox.Visible = false;
            }
        }

        private void exit_Click(object sender, EventArgs e)
        {
            // closes out the window
            this.Close();
        }
    }
}
