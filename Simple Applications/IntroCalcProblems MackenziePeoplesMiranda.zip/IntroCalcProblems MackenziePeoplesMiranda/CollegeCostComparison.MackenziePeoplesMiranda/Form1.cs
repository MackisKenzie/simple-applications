﻿//Author: Mackenzie Peoples Miranda
//ID:
//Date: 6/21/23
//Goal-Purpose of the Program: The goal of this program is to calculate the costs of two different schools at the same time
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace CollegeCostComparison.MackenziePeoplesMiranda
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            
            InitializeComponent();
        }

        private void Calculatebutton_Click(object sender, EventArgs e)
        {
            // How many trips going and coming back for the year for 1st college variable
            decimal onewaytripcount;

            // how many miles per trip for 1st college variable
            decimal onewaymiles;

            // how much an aplication cost for 1st college variable
            decimal aplicationcost;

            // how much annual tuition cost for 1st college variable
            decimal tuitioncost;

            // board room cost for 1st college variable
            decimal roomcost;

            // formula for determining MPG at 2.50 per gallon for 1st college variable
            decimal total;

            // formula for adding everything up and multiplying by 4 for 1st college variable
            decimal total4year;




            // How many trips for going and coming back for the year for 2nd college variable
            decimal onewaytripcount2;

            // How many miles per trip for 2nd college variable
            decimal onewaymiles2;

            // How much an aplication cost for 2nd college variable
            decimal aplicationcost2;

            // How much annual tuition cost for 2nd college variable
            decimal tuitioncost2;

            // Board room cost for 2nd college variable
            decimal roomcost2;

            // Formula for determining MPG at 2.50 per gallon for 2nd college variable
            decimal total2;

            // Formula for adding everything up and multiplying by 4 for 2nd college variable
            decimal total4year2;


            // Getting the one way trip count
            onewaytripcount = decimal.Parse(College1textbox3rd.Text);

            // Getting the trip miles
            onewaymiles = decimal.Parse(College1textbox4th.Text);

            // Getting the application costs
            aplicationcost = decimal.Parse(College1textbox5th.Text);

            // Getting the tuition cost
            tuitioncost = decimal.Parse(College1textbox6th.Text);

            // Getting the roomcost
            roomcost = decimal.Parse(College1textbox7th.Text);

            // Getting the one way trip count for the 2nd college
            onewaytripcount2 = decimal.Parse(College2textbox3rd.Text);

            // Getting the trip miles for the 2nd college
            onewaymiles2 = decimal.Parse(College2textbox4th.Text);

            // Getting the aplication cost for the 2nd college
            aplicationcost2 = decimal.Parse(College2textbox5th.Text);

            // Getting the tuition cost for the 2nd college
            tuitioncost2 = decimal.Parse(College2textbox6th.Text);

            // Getting the board room cost for the 2nd college
            roomcost2 = decimal.Parse(College2textbox7th.Text);


            // This formula determines how much money is spent on fuel for the year for the 1st college based on 
            // 25 MPG and 2.50$ per gallon for the 1st college
            total = onewaytripcount * onewaymiles * 0.1m * 2;

            // All veriables added and multiplied for a 4 year span for the 1st college
            total4year = total * 4 + aplicationcost * 4 + tuitioncost * 4 + roomcost * 4;



            // This formula determines how much money is spent on fuel for the year for the 1st college based on 
            // 25 MPG and 2.50$ per gallon for the 2nd college
            total2 = onewaytripcount2 * onewaymiles2 * 0.1m * 2;

            // All veriables added and multiplied for a 4 year span for the 2nd college
            total4year2 = total2 * 4 + aplicationcost2 * 4 + tuitioncost2 * 4 + roomcost2 * 4;


            // Displays the total value of fuel costs in currency for the 1st college
            College1textbox1year.Text = total.ToString("c");

            // Displays the total valuse of all variables added and multiplied by 4 for the 1st college
            College1textbox4year.Text = total4year.ToString("c");

            // Changes color of the textbox for the 1st college 4 year textbox
            College1textbox4year.BackColor = Color.Red;
            College1textbox4year.ForeColor = Color.White;

            // Displays the total value of fuel costs in currency for the 2nd college
            College2textbox1year.Text = total2.ToString("c");

            // Displays the total valuse of all variables added and multiplied by 4 for the 2nd college
            College2textbox4year.Text = total4year2.ToString("c");

            // Changes the color of the textbox for the 2nd college 4 year textbox
            College2textbox4year.BackColor = Color.Red;
            College2textbox4year.ForeColor = Color.White;
        }

        private void Exitbutton_Click(object sender, EventArgs e)
        {
            // Exits the application
            Close();
        }
    }
    }
