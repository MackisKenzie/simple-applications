﻿using System;

namespace CollegeCostComparison.MackenziePeoplesMiranda
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.College1textbox1st = new System.Windows.Forms.TextBox();
            this.College2textbox1st = new System.Windows.Forms.TextBox();
            this.College1textbox2nd = new System.Windows.Forms.TextBox();
            this.College2textbox2nd = new System.Windows.Forms.TextBox();
            this.College2textbox3rd = new System.Windows.Forms.TextBox();
            this.College1textbox3rd = new System.Windows.Forms.TextBox();
            this.College1textbox4th = new System.Windows.Forms.TextBox();
            this.College2textbox4th = new System.Windows.Forms.TextBox();
            this.College1textbox5th = new System.Windows.Forms.TextBox();
            this.College2textbox5th = new System.Windows.Forms.TextBox();
            this.College1textbox6th = new System.Windows.Forms.TextBox();
            this.College2textbox6th = new System.Windows.Forms.TextBox();
            this.College1textbox7th = new System.Windows.Forms.TextBox();
            this.College2textbox7th = new System.Windows.Forms.TextBox();
            this.College1label = new System.Windows.Forms.Label();
            this.College2label = new System.Windows.Forms.Label();
            this.Calculatebutton = new System.Windows.Forms.Button();
            this.Instructionlabel = new System.Windows.Forms.Label();
            this.Calculationlabel = new System.Windows.Forms.Label();
            this.Calculated = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.College1textbox1year = new System.Windows.Forms.TextBox();
            this.College2textbox1year = new System.Windows.Forms.TextBox();
            this.College1textbox4year = new System.Windows.Forms.TextBox();
            this.College2textbox4year = new System.Windows.Forms.TextBox();
            this.College1labelcalculation = new System.Windows.Forms.Label();
            this.College2labelcalculation = new System.Windows.Forms.Label();
            this.Exitbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // College1textbox1st
            // 
            this.College1textbox1st.BackColor = System.Drawing.Color.White;
            this.College1textbox1st.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.College1textbox1st.Cursor = System.Windows.Forms.Cursors.Hand;
            this.College1textbox1st.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.College1textbox1st.ForeColor = System.Drawing.SystemColors.MenuText;
            this.College1textbox1st.Location = new System.Drawing.Point(204, 54);
            this.College1textbox1st.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.College1textbox1st.Name = "College1textbox1st";
            this.College1textbox1st.Size = new System.Drawing.Size(116, 20);
            this.College1textbox1st.TabIndex = 0;
            this.College1textbox1st.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // College2textbox1st
            // 
            this.College2textbox1st.BackColor = System.Drawing.Color.White;
            this.College2textbox1st.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.College2textbox1st.Cursor = System.Windows.Forms.Cursors.Hand;
            this.College2textbox1st.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.College2textbox1st.ForeColor = System.Drawing.SystemColors.MenuText;
            this.College2textbox1st.Location = new System.Drawing.Point(343, 54);
            this.College2textbox1st.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.College2textbox1st.Name = "College2textbox1st";
            this.College2textbox1st.Size = new System.Drawing.Size(116, 20);
            this.College2textbox1st.TabIndex = 1;
            this.College2textbox1st.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // College1textbox2nd
            // 
            this.College1textbox2nd.BackColor = System.Drawing.Color.White;
            this.College1textbox2nd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.College1textbox2nd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.College1textbox2nd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.College1textbox2nd.ForeColor = System.Drawing.SystemColors.MenuText;
            this.College1textbox2nd.Location = new System.Drawing.Point(204, 93);
            this.College1textbox2nd.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.College1textbox2nd.Name = "College1textbox2nd";
            this.College1textbox2nd.Size = new System.Drawing.Size(116, 20);
            this.College1textbox2nd.TabIndex = 2;
            this.College1textbox2nd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // College2textbox2nd
            // 
            this.College2textbox2nd.BackColor = System.Drawing.Color.White;
            this.College2textbox2nd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.College2textbox2nd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.College2textbox2nd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.College2textbox2nd.ForeColor = System.Drawing.SystemColors.MenuText;
            this.College2textbox2nd.Location = new System.Drawing.Point(343, 93);
            this.College2textbox2nd.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.College2textbox2nd.Name = "College2textbox2nd";
            this.College2textbox2nd.Size = new System.Drawing.Size(116, 20);
            this.College2textbox2nd.TabIndex = 3;
            this.College2textbox2nd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // College2textbox3rd
            // 
            this.College2textbox3rd.BackColor = System.Drawing.Color.White;
            this.College2textbox3rd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.College2textbox3rd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.College2textbox3rd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.College2textbox3rd.ForeColor = System.Drawing.SystemColors.MenuText;
            this.College2textbox3rd.Location = new System.Drawing.Point(343, 148);
            this.College2textbox3rd.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.College2textbox3rd.Name = "College2textbox3rd";
            this.College2textbox3rd.Size = new System.Drawing.Size(116, 20);
            this.College2textbox3rd.TabIndex = 4;
            this.College2textbox3rd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // College1textbox3rd
            // 
            this.College1textbox3rd.BackColor = System.Drawing.Color.White;
            this.College1textbox3rd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.College1textbox3rd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.College1textbox3rd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.College1textbox3rd.ForeColor = System.Drawing.SystemColors.MenuText;
            this.College1textbox3rd.Location = new System.Drawing.Point(204, 148);
            this.College1textbox3rd.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.College1textbox3rd.Name = "College1textbox3rd";
            this.College1textbox3rd.Size = new System.Drawing.Size(116, 20);
            this.College1textbox3rd.TabIndex = 5;
            this.College1textbox3rd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // College1textbox4th
            // 
            this.College1textbox4th.BackColor = System.Drawing.Color.White;
            this.College1textbox4th.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.College1textbox4th.Cursor = System.Windows.Forms.Cursors.Hand;
            this.College1textbox4th.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.College1textbox4th.ForeColor = System.Drawing.SystemColors.MenuText;
            this.College1textbox4th.Location = new System.Drawing.Point(204, 205);
            this.College1textbox4th.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.College1textbox4th.Name = "College1textbox4th";
            this.College1textbox4th.Size = new System.Drawing.Size(116, 20);
            this.College1textbox4th.TabIndex = 6;
            this.College1textbox4th.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // College2textbox4th
            // 
            this.College2textbox4th.BackColor = System.Drawing.Color.White;
            this.College2textbox4th.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.College2textbox4th.Cursor = System.Windows.Forms.Cursors.Hand;
            this.College2textbox4th.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.College2textbox4th.ForeColor = System.Drawing.SystemColors.MenuText;
            this.College2textbox4th.Location = new System.Drawing.Point(343, 205);
            this.College2textbox4th.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.College2textbox4th.Name = "College2textbox4th";
            this.College2textbox4th.Size = new System.Drawing.Size(116, 20);
            this.College2textbox4th.TabIndex = 7;
            this.College2textbox4th.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // College1textbox5th
            // 
            this.College1textbox5th.BackColor = System.Drawing.Color.White;
            this.College1textbox5th.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.College1textbox5th.Cursor = System.Windows.Forms.Cursors.Hand;
            this.College1textbox5th.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.College1textbox5th.ForeColor = System.Drawing.SystemColors.MenuText;
            this.College1textbox5th.Location = new System.Drawing.Point(204, 261);
            this.College1textbox5th.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.College1textbox5th.Name = "College1textbox5th";
            this.College1textbox5th.Size = new System.Drawing.Size(116, 20);
            this.College1textbox5th.TabIndex = 8;
            this.College1textbox5th.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // College2textbox5th
            // 
            this.College2textbox5th.BackColor = System.Drawing.Color.White;
            this.College2textbox5th.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.College2textbox5th.Cursor = System.Windows.Forms.Cursors.Hand;
            this.College2textbox5th.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.College2textbox5th.ForeColor = System.Drawing.SystemColors.MenuText;
            this.College2textbox5th.Location = new System.Drawing.Point(343, 261);
            this.College2textbox5th.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.College2textbox5th.Name = "College2textbox5th";
            this.College2textbox5th.Size = new System.Drawing.Size(116, 20);
            this.College2textbox5th.TabIndex = 9;
            this.College2textbox5th.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // College1textbox6th
            // 
            this.College1textbox6th.BackColor = System.Drawing.Color.White;
            this.College1textbox6th.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.College1textbox6th.Cursor = System.Windows.Forms.Cursors.Hand;
            this.College1textbox6th.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.College1textbox6th.ForeColor = System.Drawing.SystemColors.MenuText;
            this.College1textbox6th.Location = new System.Drawing.Point(204, 312);
            this.College1textbox6th.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.College1textbox6th.Name = "College1textbox6th";
            this.College1textbox6th.Size = new System.Drawing.Size(116, 20);
            this.College1textbox6th.TabIndex = 10;
            this.College1textbox6th.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // College2textbox6th
            // 
            this.College2textbox6th.BackColor = System.Drawing.Color.White;
            this.College2textbox6th.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.College2textbox6th.Cursor = System.Windows.Forms.Cursors.Hand;
            this.College2textbox6th.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.College2textbox6th.ForeColor = System.Drawing.SystemColors.MenuText;
            this.College2textbox6th.Location = new System.Drawing.Point(343, 312);
            this.College2textbox6th.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.College2textbox6th.Name = "College2textbox6th";
            this.College2textbox6th.Size = new System.Drawing.Size(116, 20);
            this.College2textbox6th.TabIndex = 11;
            this.College2textbox6th.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // College1textbox7th
            // 
            this.College1textbox7th.BackColor = System.Drawing.Color.White;
            this.College1textbox7th.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.College1textbox7th.Cursor = System.Windows.Forms.Cursors.Hand;
            this.College1textbox7th.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.College1textbox7th.ForeColor = System.Drawing.SystemColors.MenuText;
            this.College1textbox7th.Location = new System.Drawing.Point(204, 351);
            this.College1textbox7th.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.College1textbox7th.Name = "College1textbox7th";
            this.College1textbox7th.Size = new System.Drawing.Size(116, 20);
            this.College1textbox7th.TabIndex = 12;
            this.College1textbox7th.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // College2textbox7th
            // 
            this.College2textbox7th.BackColor = System.Drawing.Color.White;
            this.College2textbox7th.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.College2textbox7th.Cursor = System.Windows.Forms.Cursors.Hand;
            this.College2textbox7th.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.College2textbox7th.ForeColor = System.Drawing.SystemColors.MenuText;
            this.College2textbox7th.Location = new System.Drawing.Point(343, 351);
            this.College2textbox7th.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.College2textbox7th.Name = "College2textbox7th";
            this.College2textbox7th.Size = new System.Drawing.Size(116, 20);
            this.College2textbox7th.TabIndex = 13;
            this.College2textbox7th.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // College1label
            // 
            this.College1label.AutoSize = true;
            this.College1label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.College1label.Location = new System.Drawing.Point(219, 34);
            this.College1label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.College1label.Name = "College1label";
            this.College1label.Size = new System.Drawing.Size(76, 17);
            this.College1label.TabIndex = 14;
            this.College1label.Text = "College 1";
            // 
            // College2label
            // 
            this.College2label.AutoSize = true;
            this.College2label.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.College2label.Location = new System.Drawing.Point(356, 34);
            this.College2label.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.College2label.Name = "College2label";
            this.College2label.Size = new System.Drawing.Size(76, 17);
            this.College2label.TabIndex = 15;
            this.College2label.Text = "College 2";
            // 
            // Calculatebutton
            // 
            this.Calculatebutton.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.Calculatebutton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Calculatebutton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Calculatebutton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Calculatebutton.Location = new System.Drawing.Point(204, 400);
            this.Calculatebutton.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Calculatebutton.Name = "Calculatebutton";
            this.Calculatebutton.Size = new System.Drawing.Size(255, 32);
            this.Calculatebutton.TabIndex = 16;
            this.Calculatebutton.Text = "Calculate";
            this.Calculatebutton.UseVisualStyleBackColor = false;
            this.Calculatebutton.Click += new System.EventHandler(this.Calculatebutton_Click);
            // 
            // Instructionlabel
            // 
            this.Instructionlabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Instructionlabel.Location = new System.Drawing.Point(-1, 55);
            this.Instructionlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Instructionlabel.Name = "Instructionlabel";
            this.Instructionlabel.Size = new System.Drawing.Size(197, 378);
            this.Instructionlabel.TabIndex = 17;
            this.Instructionlabel.Text = resources.GetString("Instructionlabel.Text");
            // 
            // Calculationlabel
            // 
            this.Calculationlabel.AutoSize = true;
            this.Calculationlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calculationlabel.Location = new System.Drawing.Point(181, 447);
            this.Calculationlabel.Name = "Calculationlabel";
            this.Calculationlabel.Size = new System.Drawing.Size(164, 24);
            this.Calculationlabel.TabIndex = 18;
            this.Calculationlabel.Text = "CALCULATIONS";
            // 
            // Calculated
            // 
            this.Calculated.AutoSize = true;
            this.Calculated.Location = new System.Drawing.Point(12, 514);
            this.Calculated.Name = "Calculated";
            this.Calculated.Size = new System.Drawing.Size(209, 13);
            this.Calculated.TabIndex = 19;
            this.Calculated.Text = "Calculated 1 Year Total FUEL Cost ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 607);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(217, 13);
            this.label2.TabIndex = 20;
            this.label2.Text = "Calculated 4 Year Total of ALL Costs";
            // 
            // College1textbox1year
            // 
            this.College1textbox1year.Cursor = System.Windows.Forms.Cursors.Default;
            this.College1textbox1year.Location = new System.Drawing.Point(245, 511);
            this.College1textbox1year.Name = "College1textbox1year";
            this.College1textbox1year.ReadOnly = true;
            this.College1textbox1year.Size = new System.Drawing.Size(105, 20);
            this.College1textbox1year.TabIndex = 21;
            this.College1textbox1year.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // College2textbox1year
            // 
            this.College2textbox1year.Cursor = System.Windows.Forms.Cursors.Default;
            this.College2textbox1year.Location = new System.Drawing.Point(378, 511);
            this.College2textbox1year.Name = "College2textbox1year";
            this.College2textbox1year.ReadOnly = true;
            this.College2textbox1year.Size = new System.Drawing.Size(100, 20);
            this.College2textbox1year.TabIndex = 22;
            this.College2textbox1year.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // College1textbox4year
            // 
            this.College1textbox4year.Cursor = System.Windows.Forms.Cursors.Default;
            this.College1textbox4year.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.College1textbox4year.Location = new System.Drawing.Point(245, 600);
            this.College1textbox4year.Name = "College1textbox4year";
            this.College1textbox4year.ReadOnly = true;
            this.College1textbox4year.Size = new System.Drawing.Size(100, 20);
            this.College1textbox4year.TabIndex = 23;
            this.College1textbox4year.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // College2textbox4year
            // 
            this.College2textbox4year.Cursor = System.Windows.Forms.Cursors.Default;
            this.College2textbox4year.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.College2textbox4year.Location = new System.Drawing.Point(378, 600);
            this.College2textbox4year.Name = "College2textbox4year";
            this.College2textbox4year.ReadOnly = true;
            this.College2textbox4year.Size = new System.Drawing.Size(100, 20);
            this.College2textbox4year.TabIndex = 24;
            this.College2textbox4year.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // College1labelcalculation
            // 
            this.College1labelcalculation.AutoSize = true;
            this.College1labelcalculation.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.College1labelcalculation.Location = new System.Drawing.Point(260, 484);
            this.College1labelcalculation.Name = "College1labelcalculation";
            this.College1labelcalculation.Size = new System.Drawing.Size(60, 13);
            this.College1labelcalculation.TabIndex = 25;
            this.College1labelcalculation.Text = "College 1";
            // 
            // College2labelcalculation
            // 
            this.College2labelcalculation.AutoSize = true;
            this.College2labelcalculation.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.College2labelcalculation.Location = new System.Drawing.Point(399, 484);
            this.College2labelcalculation.Name = "College2labelcalculation";
            this.College2labelcalculation.Size = new System.Drawing.Size(60, 13);
            this.College2labelcalculation.TabIndex = 26;
            this.College2labelcalculation.Text = "College 2";
            // 
            // Exitbutton
            // 
            this.Exitbutton.Location = new System.Drawing.Point(204, 657);
            this.Exitbutton.Name = "Exitbutton";
            this.Exitbutton.Size = new System.Drawing.Size(75, 23);
            this.Exitbutton.TabIndex = 27;
            this.Exitbutton.Text = "Exit";
            this.Exitbutton.UseVisualStyleBackColor = true;
            this.Exitbutton.Click += new System.EventHandler(this.Exitbutton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(490, 692);
            this.Controls.Add(this.Exitbutton);
            this.Controls.Add(this.College2labelcalculation);
            this.Controls.Add(this.College1labelcalculation);
            this.Controls.Add(this.College2textbox4year);
            this.Controls.Add(this.College1textbox4year);
            this.Controls.Add(this.College2textbox1year);
            this.Controls.Add(this.College1textbox1year);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Calculated);
            this.Controls.Add(this.Calculationlabel);
            this.Controls.Add(this.Instructionlabel);
            this.Controls.Add(this.Calculatebutton);
            this.Controls.Add(this.College2label);
            this.Controls.Add(this.College1label);
            this.Controls.Add(this.College2textbox7th);
            this.Controls.Add(this.College1textbox7th);
            this.Controls.Add(this.College2textbox6th);
            this.Controls.Add(this.College1textbox6th);
            this.Controls.Add(this.College2textbox5th);
            this.Controls.Add(this.College1textbox5th);
            this.Controls.Add(this.College2textbox4th);
            this.Controls.Add(this.College1textbox4th);
            this.Controls.Add(this.College1textbox3rd);
            this.Controls.Add(this.College2textbox3rd);
            this.Controls.Add(this.College2textbox2nd);
            this.Controls.Add(this.College1textbox2nd);
            this.Controls.Add(this.College2textbox1st);
            this.Controls.Add(this.College1textbox1st);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void TextBox8_TextChanged(object sender, EventArgs e, NotImplementedException notImplementedException)
        {
            throw notImplementedException;
        }



        #endregion

        private System.Windows.Forms.TextBox College1textbox1st;
        private System.Windows.Forms.TextBox College2textbox1st;
        private System.Windows.Forms.TextBox College1textbox2nd;
        private System.Windows.Forms.TextBox College2textbox2nd;
        private System.Windows.Forms.TextBox College2textbox3rd;
        private System.Windows.Forms.TextBox College1textbox3rd;
        private System.Windows.Forms.TextBox College1textbox4th;
        private System.Windows.Forms.TextBox College2textbox4th;
        private System.Windows.Forms.TextBox College1textbox5th;
        private System.Windows.Forms.TextBox College2textbox5th;
        private System.Windows.Forms.TextBox College1textbox6th;
        private System.Windows.Forms.TextBox College2textbox6th;
        private System.Windows.Forms.TextBox College1textbox7th;
        private System.Windows.Forms.TextBox College2textbox7th;
        private System.Windows.Forms.Label College1label;
        private System.Windows.Forms.Label College2label;
        private System.Windows.Forms.Button Calculatebutton;
        private System.Windows.Forms.Label Instructionlabel;
        private System.Windows.Forms.Label Calculationlabel;
        private System.Windows.Forms.Label Calculated;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox College1textbox1year;
        private System.Windows.Forms.TextBox College2textbox1year;
        private System.Windows.Forms.TextBox College1textbox4year;
        private System.Windows.Forms.TextBox College2textbox4year;
        private System.Windows.Forms.Label College1labelcalculation;
        private System.Windows.Forms.Label College2labelcalculation;
        private System.Windows.Forms.Button Exitbutton;
    }
}

