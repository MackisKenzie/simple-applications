﻿namespace SalesTaxCalc.MackenziePeoplesMiranda
{
    partial class SalesTaxCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Pricetextbox = new System.Windows.Forms.TextBox();
            this.Taxtextbox = new System.Windows.Forms.TextBox();
            this.Totaltextbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.calculatebutton = new System.Windows.Forms.Button();
            this.Exitbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Pricetextbox
            // 
            this.Pricetextbox.Location = new System.Drawing.Point(138, 61);
            this.Pricetextbox.Name = "Pricetextbox";
            this.Pricetextbox.Size = new System.Drawing.Size(100, 20);
            this.Pricetextbox.TabIndex = 0;
            this.Pricetextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Taxtextbox
            // 
            this.Taxtextbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Taxtextbox.Location = new System.Drawing.Point(138, 113);
            this.Taxtextbox.Name = "Taxtextbox";
            this.Taxtextbox.ReadOnly = true;
            this.Taxtextbox.Size = new System.Drawing.Size(100, 20);
            this.Taxtextbox.TabIndex = 1;
            this.Taxtextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Totaltextbox
            // 
            this.Totaltextbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Totaltextbox.Location = new System.Drawing.Point(138, 169);
            this.Totaltextbox.Name = "Totaltextbox";
            this.Totaltextbox.ReadOnly = true;
            this.Totaltextbox.Size = new System.Drawing.Size(100, 20);
            this.Totaltextbox.TabIndex = 2;
            this.Totaltextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(100, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Price";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(47, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Sales tax at 6.5%";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(47, 176);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Total sales price";
            // 
            // calculatebutton
            // 
            this.calculatebutton.Location = new System.Drawing.Point(32, 209);
            this.calculatebutton.Name = "calculatebutton";
            this.calculatebutton.Size = new System.Drawing.Size(75, 23);
            this.calculatebutton.TabIndex = 6;
            this.calculatebutton.Text = "Calculate";
            this.calculatebutton.UseVisualStyleBackColor = true;
            this.calculatebutton.Click += new System.EventHandler(this.Calculatebutton_Click);
            // 
            // Exitbutton
            // 
            this.Exitbutton.Location = new System.Drawing.Point(128, 209);
            this.Exitbutton.Name = "Exitbutton";
            this.Exitbutton.Size = new System.Drawing.Size(75, 23);
            this.Exitbutton.TabIndex = 7;
            this.Exitbutton.Text = "Exit";
            this.Exitbutton.UseVisualStyleBackColor = true;
            this.Exitbutton.Click += new System.EventHandler(this.Exitbutton_Click);
            // 
            // SalesTaxCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(269, 257);
            this.Controls.Add(this.Exitbutton);
            this.Controls.Add(this.calculatebutton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Totaltextbox);
            this.Controls.Add(this.Taxtextbox);
            this.Controls.Add(this.Pricetextbox);
            this.Name = "SalesTaxCalculator";
            this.Text = "SalesTaxCalculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Pricetextbox;
        private System.Windows.Forms.TextBox Taxtextbox;
        private System.Windows.Forms.TextBox Totaltextbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button calculatebutton;
        private System.Windows.Forms.Button Exitbutton;
    }
}

