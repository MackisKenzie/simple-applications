﻿//Author: Mackenzie Peoples Miranda
//ID: 
//Date: 6/19/23
//Goal of Program: The goal of this program is to calculate sales tax.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesTaxCalc.MackenziePeoplesMiranda
{
    public partial class SalesTaxCalculator : Form
    {
        public SalesTaxCalculator()
        {
            InitializeComponent();
        }

        private void Calculatebutton_Click(object sender, EventArgs e)
        {
            decimal price;
            decimal tax;
            decimal total;

            // price input
            price = decimal.Parse(Pricetextbox.Text);

            // calculating the tax
            tax = price * 0.065m;

            // combining both tax and price input
            total = price + tax;

            // displaying the tax into the textbox
            Taxtextbox.Text = tax.ToString("c");

            // displaying the grand total into the textbox
            Totaltextbox.Text = total.ToString("c");

        }

        private void Exitbutton_Click(object sender, EventArgs e)
        {
            // closes out the application
            this.Close();
        }
    }
}
