﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Author: Mackenzie Peoples Miranda
//ID: 
//Date: 6/25/23
//Goal: the goal is to determine the miles, minutes spent and calories based on
//      how many steps were taken
namespace CalcValidationMackenziePeoplesMiranda
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Calculatebutton_Click(object sender, EventArgs e)
        {
            // the varibales for the steps, distance, time, and calories
            decimal steps;
            decimal distance;
            decimal timespent;
            decimal calories;
            decimal lbs;


            // try&catch for when the wrong format is entered 
            try
            {
                steps = decimal.Parse(Stepstextbox.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("ERROR!: Must be in numeric format (0-9)");
                return;

            }

            // formula for the textboxes
            distance = steps / 2000;
            timespent = steps / 100;
            calories = steps / 20;
            lbs = calories / 3500;

            Distancetextbox.Text = distance.ToString();
            Distancetextbox.Enabled = false;

            Timespenttextbox.Text = timespent.ToString();
            Timespenttextbox.Enabled = false;

            Caloriestextbox.Text = calories.ToString();
            Caloriestextbox.Enabled = false;

            Lbstextbox.Text = lbs.ToString();
            Lbstextbox.Enabled = false;





        }

        // closes the application
        private void Exitbutton_Click(object sender, EventArgs e)
        {
            Close();


        }

        // Enter the values for the milkshake
        private void Button1_Click(object sender, EventArgs e)
        {

            Stepstextbox.Text = "9380";

            Distancetextbox.Text = "4.69";

            Timespenttextbox.Text = "93.8";

            Caloriestextbox.Text = "496";

            Lbstextbox.Text = "0.134";


        }

        // Clears all textboxes
        private void Clearbutton_Click(object sender, EventArgs e)
        {

            Stepstextbox.Text = "";

            Distancetextbox.Text = "";

            Timespenttextbox.Text = "";

            Caloriestextbox.Text = "";

            Lbstextbox.Text = "";

        }
    }
}
