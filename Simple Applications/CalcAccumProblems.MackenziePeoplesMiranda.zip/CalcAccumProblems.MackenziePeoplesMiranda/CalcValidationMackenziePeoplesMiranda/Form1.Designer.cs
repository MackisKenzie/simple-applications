﻿namespace CalcValidationMackenziePeoplesMiranda
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Calculatebutton = new System.Windows.Forms.Button();
            this.Exitbutton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Stepstextbox = new System.Windows.Forms.TextBox();
            this.Distancetextbox = new System.Windows.Forms.TextBox();
            this.Timespenttextbox = new System.Windows.Forms.TextBox();
            this.Caloriestextbox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Lbstextbox = new System.Windows.Forms.TextBox();
            this.Button1 = new System.Windows.Forms.Button();
            this.Clearbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Calculatebutton
            // 
            this.Calculatebutton.Location = new System.Drawing.Point(12, 354);
            this.Calculatebutton.Name = "Calculatebutton";
            this.Calculatebutton.Size = new System.Drawing.Size(75, 23);
            this.Calculatebutton.TabIndex = 0;
            this.Calculatebutton.Text = "Calculate";
            this.Calculatebutton.UseVisualStyleBackColor = true;
            this.Calculatebutton.Click += new System.EventHandler(this.Calculatebutton_Click);
            // 
            // Exitbutton
            // 
            this.Exitbutton.Location = new System.Drawing.Point(174, 354);
            this.Exitbutton.Name = "Exitbutton";
            this.Exitbutton.Size = new System.Drawing.Size(75, 23);
            this.Exitbutton.TabIndex = 1;
            this.Exitbutton.Text = "Exit";
            this.Exitbutton.UseVisualStyleBackColor = true;
            this.Exitbutton.Click += new System.EventHandler(this.Exitbutton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Enter how many steps";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Distance in miles";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Time spent in minutes";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 229);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Calories Burned";
            // 
            // Stepstextbox
            // 
            this.Stepstextbox.Location = new System.Drawing.Point(158, 42);
            this.Stepstextbox.Name = "Stepstextbox";
            this.Stepstextbox.Size = new System.Drawing.Size(100, 20);
            this.Stepstextbox.TabIndex = 6;
            this.Stepstextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Distancetextbox
            // 
            this.Distancetextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Distancetextbox.Location = new System.Drawing.Point(158, 98);
            this.Distancetextbox.Name = "Distancetextbox";
            this.Distancetextbox.ReadOnly = true;
            this.Distancetextbox.Size = new System.Drawing.Size(100, 20);
            this.Distancetextbox.TabIndex = 7;
            this.Distancetextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Timespenttextbox
            // 
            this.Timespenttextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Timespenttextbox.Location = new System.Drawing.Point(158, 164);
            this.Timespenttextbox.Name = "Timespenttextbox";
            this.Timespenttextbox.ReadOnly = true;
            this.Timespenttextbox.Size = new System.Drawing.Size(100, 20);
            this.Timespenttextbox.TabIndex = 8;
            this.Timespenttextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Caloriestextbox
            // 
            this.Caloriestextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Caloriestextbox.Location = new System.Drawing.Point(158, 222);
            this.Caloriestextbox.Name = "Caloriestextbox";
            this.Caloriestextbox.ReadOnly = true;
            this.Caloriestextbox.Size = new System.Drawing.Size(100, 20);
            this.Caloriestextbox.TabIndex = 9;
            this.Caloriestextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(30, 281);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Lbs burned";
            // 
            // Lbstextbox
            // 
            this.Lbstextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbstextbox.Location = new System.Drawing.Point(158, 274);
            this.Lbstextbox.Name = "Lbstextbox";
            this.Lbstextbox.ReadOnly = true;
            this.Lbstextbox.Size = new System.Drawing.Size(100, 20);
            this.Lbstextbox.TabIndex = 11;
            this.Lbstextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Button1
            // 
            this.Button1.AutoSize = true;
            this.Button1.Location = new System.Drawing.Point(48, 325);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(177, 23);
            this.Button1.TabIndex = 12;
            this.Button1.Text = "Calculate a McDonalds milkshake";
            this.Button1.UseVisualStyleBackColor = true;
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // Clearbutton
            // 
            this.Clearbutton.FlatAppearance.BorderColor = System.Drawing.Color.Fuchsia;
            this.Clearbutton.FlatAppearance.BorderSize = 8;
            this.Clearbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clearbutton.Location = new System.Drawing.Point(93, 354);
            this.Clearbutton.Name = "Clearbutton";
            this.Clearbutton.Size = new System.Drawing.Size(75, 23);
            this.Clearbutton.TabIndex = 13;
            this.Clearbutton.Text = "Clear";
            this.Clearbutton.UseVisualStyleBackColor = true;
            this.Clearbutton.Click += new System.EventHandler(this.Clearbutton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(270, 399);
            this.Controls.Add(this.Clearbutton);
            this.Controls.Add(this.Button1);
            this.Controls.Add(this.Lbstextbox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Caloriestextbox);
            this.Controls.Add(this.Timespenttextbox);
            this.Controls.Add(this.Distancetextbox);
            this.Controls.Add(this.Stepstextbox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Exitbutton);
            this.Controls.Add(this.Calculatebutton);
            this.Name = "Form1";
            this.Text = "CalcValidation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Calculatebutton;
        private System.Windows.Forms.Button Exitbutton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Stepstextbox;
        private System.Windows.Forms.TextBox Distancetextbox;
        private System.Windows.Forms.TextBox Timespenttextbox;
        private System.Windows.Forms.TextBox Caloriestextbox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Lbstextbox;
        private System.Windows.Forms.Button Button1;
        private System.Windows.Forms.Button Clearbutton;
    }
}

