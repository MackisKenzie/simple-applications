﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.Collections.Specialized;
// Mackenzie Peoples Miranda
// id
// 6/26/23
// goal is to calculate mulch costs


namespace CalcWithAccums.MackenziePeoplesMiranda
{
    public partial class Form1 : Form
    {

    
        public Form1()


        {
            InitializeComponent();
        }

        // variables 
        const decimal cubicyards = 27;
        const decimal priceperyard = 20;
        const decimal truckyardmax = 4;
        decimal cubicftall = 0;
        decimal cubicyardsall = 0;
        decimal costall = 0;
        decimal alltotalorders = 0;

        private void Calculatebutton_Click(object sender, EventArgs e)
        {
            // variables 
            decimal length  ;
            decimal width  ;
            decimal height   ;
            decimal cubicft  ;
            decimal cubicyards ;
            decimal priceperyard ;
            decimal emptytruck ;

            // formulas for variables
            length = decimal.Parse(Lengthtextbox.Text);
            width = decimal.Parse(Widthtextbox.Text);
            height = decimal.Parse(Heighttextbox.Text);
            cubicft = length * width * height;
            cubicyards = cubicft / 27;
            priceperyard = 20.00m * cubicyards;
            emptytruck = 4 - cubicyardsall ;

            // formulas for variables
            costall = priceperyard + costall;
            alltotalorders = 1 + alltotalorders;
            cubicftall = cubicft + cubicftall;
            cubicyardsall = cubicyards + cubicyardsall;
            
            // diplays text to textbox
            Cubicfeettextbox.Text = cubicft.ToString("n2");
            Cubicyardstextbox.Text = cubicyards.ToString("n2");
            Priceperyardtextbox.Text = priceperyard.ToString("c");
            // diplays text to textbox
            Totalorderstextbox.Text = alltotalorders.ToString("n0");
            CostALLtextbox.Text = costall.ToString("c");
            CubicftALLtextbox.Text = cubicftall.ToString("n0");
            CubicyardsALLtextbox.Text = cubicyardsall.ToString("n2");
            Emptytrucktextbox.Text = truckyardmax.ToString();
            Lessordertextbox.Text = cubicyardsall.ToString("n2");

            Equalstrucktextbox.Text = emptytruck.ToString("n2");
            // changes color if greater or less than
            if ( emptytruck > 0 )
            { Equalstrucktextbox.BackColor = Color.LightGreen; }
            else
            { Equalstrucktextbox.BackColor = Color.Yellow; }
        }


        // clears the textboxes
        private void Clearbutton_Click(object sender, EventArgs e)
        {
            Lengthtextbox.Text = "";
            Widthtextbox.Text = "";
            Heighttextbox.Text = "";

            Cubicfeettextbox.Text = "";
            Cubicyardstextbox.Text = "";
            Priceperyardtextbox.Text = "";

            Totalorderstextbox.Text = "";
            CostALLtextbox.Text = "";
            CubicftALLtextbox.Text = "";

            CubicyardsALLtextbox.Text = "";
            Emptytrucktextbox.Text = "";
            Lessordertextbox.Text = "";

            Equalstrucktextbox.Text = "";


            Equalstrucktextbox.BackColor = Color.LightGreen;

        }
    }
}
