﻿namespace CalcWithAccums.MackenziePeoplesMiranda
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Landcompany = new System.Windows.Forms.Label();
            this.Lengthtextbox = new System.Windows.Forms.TextBox();
            this.Widthtextbox = new System.Windows.Forms.TextBox();
            this.Heighttextbox = new System.Windows.Forms.TextBox();
            this.Calculatebutton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Priceperyardtextbox = new System.Windows.Forms.TextBox();
            this.Cubicyardstextbox = new System.Windows.Forms.TextBox();
            this.Cubicfeettextbox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Totalorderstextbox = new System.Windows.Forms.TextBox();
            this.CostALLtextbox = new System.Windows.Forms.TextBox();
            this.CubicyardsALLtextbox = new System.Windows.Forms.TextBox();
            this.CubicftALLtextbox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Emptytrucktextbox = new System.Windows.Forms.TextBox();
            this.Lessordertextbox = new System.Windows.Forms.TextBox();
            this.Equalstrucktextbox = new System.Windows.Forms.TextBox();
            this.Clearbutton = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter Length (ft)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Enter Width (ft)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Enter Height (ft)";
            // 
            // Landcompany
            // 
            this.Landcompany.AutoSize = true;
            this.Landcompany.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Landcompany.Location = new System.Drawing.Point(59, 9);
            this.Landcompany.Name = "Landcompany";
            this.Landcompany.Size = new System.Drawing.Size(532, 31);
            this.Landcompany.TabIndex = 3;
            this.Landcompany.Text = "Mackenzie Miranda Landscaping Company";
            // 
            // Lengthtextbox
            // 
            this.Lengthtextbox.Location = new System.Drawing.Point(127, 74);
            this.Lengthtextbox.Name = "Lengthtextbox";
            this.Lengthtextbox.Size = new System.Drawing.Size(100, 20);
            this.Lengthtextbox.TabIndex = 4;
            // 
            // Widthtextbox
            // 
            this.Widthtextbox.Location = new System.Drawing.Point(127, 100);
            this.Widthtextbox.Name = "Widthtextbox";
            this.Widthtextbox.Size = new System.Drawing.Size(100, 20);
            this.Widthtextbox.TabIndex = 5;
            // 
            // Heighttextbox
            // 
            this.Heighttextbox.Location = new System.Drawing.Point(127, 126);
            this.Heighttextbox.Name = "Heighttextbox";
            this.Heighttextbox.Size = new System.Drawing.Size(100, 20);
            this.Heighttextbox.TabIndex = 6;
            // 
            // Calculatebutton
            // 
            this.Calculatebutton.Location = new System.Drawing.Point(12, 160);
            this.Calculatebutton.Name = "Calculatebutton";
            this.Calculatebutton.Size = new System.Drawing.Size(215, 23);
            this.Calculatebutton.TabIndex = 7;
            this.Calculatebutton.Text = "Calculate";
            this.Calculatebutton.UseVisualStyleBackColor = true;
            this.Calculatebutton.Click += new System.EventHandler(this.Calculatebutton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Priceperyardtextbox);
            this.groupBox1.Controls.Add(this.Cubicyardstextbox);
            this.groupBox1.Controls.Add(this.Cubicfeettextbox);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(12, 215);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(215, 173);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Current Order";
            // 
            // Priceperyardtextbox
            // 
            this.Priceperyardtextbox.Location = new System.Drawing.Point(109, 108);
            this.Priceperyardtextbox.Name = "Priceperyardtextbox";
            this.Priceperyardtextbox.ReadOnly = true;
            this.Priceperyardtextbox.Size = new System.Drawing.Size(100, 20);
            this.Priceperyardtextbox.TabIndex = 9;
            // 
            // Cubicyardstextbox
            // 
            this.Cubicyardstextbox.Location = new System.Drawing.Point(109, 63);
            this.Cubicyardstextbox.Name = "Cubicyardstextbox";
            this.Cubicyardstextbox.ReadOnly = true;
            this.Cubicyardstextbox.Size = new System.Drawing.Size(100, 20);
            this.Cubicyardstextbox.TabIndex = 8;
            // 
            // Cubicfeettextbox
            // 
            this.Cubicfeettextbox.Location = new System.Drawing.Point(109, 24);
            this.Cubicfeettextbox.Name = "Cubicfeettextbox";
            this.Cubicfeettextbox.ReadOnly = true;
            this.Cubicfeettextbox.Size = new System.Drawing.Size(100, 20);
            this.Cubicfeettextbox.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 111);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "@$   20 per yard =";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 66);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Cubic Yards";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Cubic Feet";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Totalorderstextbox);
            this.groupBox2.Controls.Add(this.CostALLtextbox);
            this.groupBox2.Controls.Add(this.CubicyardsALLtextbox);
            this.groupBox2.Controls.Add(this.CubicftALLtextbox);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Location = new System.Drawing.Point(247, 215);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(249, 173);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Total of All Orders";
            // 
            // Totalorderstextbox
            // 
            this.Totalorderstextbox.Location = new System.Drawing.Point(143, 143);
            this.Totalorderstextbox.Name = "Totalorderstextbox";
            this.Totalorderstextbox.ReadOnly = true;
            this.Totalorderstextbox.Size = new System.Drawing.Size(100, 20);
            this.Totalorderstextbox.TabIndex = 13;
            // 
            // CostALLtextbox
            // 
            this.CostALLtextbox.Location = new System.Drawing.Point(143, 108);
            this.CostALLtextbox.Name = "CostALLtextbox";
            this.CostALLtextbox.ReadOnly = true;
            this.CostALLtextbox.Size = new System.Drawing.Size(100, 20);
            this.CostALLtextbox.TabIndex = 12;
            // 
            // CubicyardsALLtextbox
            // 
            this.CubicyardsALLtextbox.Location = new System.Drawing.Point(143, 63);
            this.CubicyardsALLtextbox.Name = "CubicyardsALLtextbox";
            this.CubicyardsALLtextbox.ReadOnly = true;
            this.CubicyardsALLtextbox.Size = new System.Drawing.Size(100, 20);
            this.CubicyardsALLtextbox.TabIndex = 11;
            // 
            // CubicftALLtextbox
            // 
            this.CubicftALLtextbox.Location = new System.Drawing.Point(143, 24);
            this.CubicftALLtextbox.Name = "CubicftALLtextbox";
            this.CubicftALLtextbox.ReadOnly = true;
            this.CubicftALLtextbox.Size = new System.Drawing.Size(100, 20);
            this.CubicftALLtextbox.TabIndex = 10;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 146);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 13);
            this.label10.TabIndex = 6;
            this.label10.Text = "Number of Orders";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 111);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "Cost (All Orders)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 66);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(118, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Cubic Yards (All Orders)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Cubic Feet (All Orders)";
            // 
            // Emptytrucktextbox
            // 
            this.Emptytrucktextbox.Location = new System.Drawing.Point(85, 403);
            this.Emptytrucktextbox.Name = "Emptytrucktextbox";
            this.Emptytrucktextbox.ReadOnly = true;
            this.Emptytrucktextbox.Size = new System.Drawing.Size(100, 20);
            this.Emptytrucktextbox.TabIndex = 9;
            // 
            // Lessordertextbox
            // 
            this.Lessordertextbox.Location = new System.Drawing.Point(292, 403);
            this.Lessordertextbox.Name = "Lessordertextbox";
            this.Lessordertextbox.ReadOnly = true;
            this.Lessordertextbox.Size = new System.Drawing.Size(100, 20);
            this.Lessordertextbox.TabIndex = 10;
            // 
            // Equalstrucktextbox
            // 
            this.Equalstrucktextbox.Location = new System.Drawing.Point(475, 403);
            this.Equalstrucktextbox.Name = "Equalstrucktextbox";
            this.Equalstrucktextbox.ReadOnly = true;
            this.Equalstrucktextbox.Size = new System.Drawing.Size(100, 20);
            this.Equalstrucktextbox.TabIndex = 11;
            this.Equalstrucktextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Clearbutton
            // 
            this.Clearbutton.Location = new System.Drawing.Point(222, 442);
            this.Clearbutton.Name = "Clearbutton";
            this.Clearbutton.Size = new System.Drawing.Size(182, 32);
            this.Clearbutton.TabIndex = 12;
            this.Clearbutton.Text = "Clear";
            this.Clearbutton.UseVisualStyleBackColor = true;
            this.Clearbutton.Click += new System.EventHandler(this.Clearbutton_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 394);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 39);
            this.label11.TabIndex = 13;
            this.label11.Text = "Empty Truck\r\nCapacity\r\n(cubic yards)";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(219, 397);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 39);
            this.label12.TabIndex = 14;
            this.label12.Text = "Less: \r\nOrdered\r\n(cubic yards)";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(412, 401);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 52);
            this.label13.TabIndex = 15;
            this.label13.Text = "Equals:\r\nTruck\r\nCapacity\r\nRemaining";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(614, 512);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.Clearbutton);
            this.Controls.Add(this.Equalstrucktextbox);
            this.Controls.Add(this.Lessordertextbox);
            this.Controls.Add(this.Emptytrucktextbox);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.Calculatebutton);
            this.Controls.Add(this.Heighttextbox);
            this.Controls.Add(this.Widthtextbox);
            this.Controls.Add(this.Lengthtextbox);
            this.Controls.Add(this.Landcompany);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Landcompany;
        private System.Windows.Forms.TextBox Lengthtextbox;
        private System.Windows.Forms.TextBox Widthtextbox;
        private System.Windows.Forms.TextBox Heighttextbox;
        private System.Windows.Forms.Button Calculatebutton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox Priceperyardtextbox;
        private System.Windows.Forms.TextBox Cubicyardstextbox;
        private System.Windows.Forms.TextBox Cubicfeettextbox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Totalorderstextbox;
        private System.Windows.Forms.TextBox CostALLtextbox;
        private System.Windows.Forms.TextBox CubicyardsALLtextbox;
        private System.Windows.Forms.TextBox CubicftALLtextbox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Emptytrucktextbox;
        private System.Windows.Forms.TextBox Lessordertextbox;
        private System.Windows.Forms.TextBox Equalstrucktextbox;
        private System.Windows.Forms.Button Clearbutton;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
    }
}
