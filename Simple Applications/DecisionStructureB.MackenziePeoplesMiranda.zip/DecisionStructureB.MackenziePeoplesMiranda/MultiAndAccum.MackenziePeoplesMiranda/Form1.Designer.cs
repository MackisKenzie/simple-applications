﻿namespace MultiAndAccum.MackenziePeoplesMiranda
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CalculatebButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.Firsttextbox = new System.Windows.Forms.TextBox();
            this.Secondtextbox = new System.Windows.Forms.TextBox();
            this.Thirdtextbox = new System.Windows.Forms.TextBox();
            this.Fourthtextbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // CalculatebButton
            // 
            this.CalculatebButton.Location = new System.Drawing.Point(64, 114);
            this.CalculatebButton.Name = "CalculatebButton";
            this.CalculatebButton.Size = new System.Drawing.Size(75, 23);
            this.CalculatebButton.TabIndex = 0;
            this.CalculatebButton.Text = "Calculate";
            this.CalculatebButton.UseVisualStyleBackColor = true;
            this.CalculatebButton.Click += new System.EventHandler(this.CalculatebButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(222, 114);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(75, 23);
            this.ClearButton.TabIndex = 1;
            this.ClearButton.Text = "Clear";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(364, 114);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(75, 23);
            this.ExitButton.TabIndex = 2;
            this.ExitButton.Text = "EXIT";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // Firsttextbox
            // 
            this.Firsttextbox.Location = new System.Drawing.Point(54, 88);
            this.Firsttextbox.Name = "Firsttextbox";
            this.Firsttextbox.Size = new System.Drawing.Size(100, 20);
            this.Firsttextbox.TabIndex = 3;
            this.Firsttextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Secondtextbox
            // 
            this.Secondtextbox.Location = new System.Drawing.Point(209, 88);
            this.Secondtextbox.Name = "Secondtextbox";
            this.Secondtextbox.Size = new System.Drawing.Size(100, 20);
            this.Secondtextbox.TabIndex = 4;
            this.Secondtextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Thirdtextbox
            // 
            this.Thirdtextbox.Location = new System.Drawing.Point(351, 88);
            this.Thirdtextbox.Name = "Thirdtextbox";
            this.Thirdtextbox.ReadOnly = true;
            this.Thirdtextbox.Size = new System.Drawing.Size(100, 20);
            this.Thirdtextbox.TabIndex = 5;
            this.Thirdtextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Fourthtextbox
            // 
            this.Fourthtextbox.Location = new System.Drawing.Point(509, 88);
            this.Fourthtextbox.Name = "Fourthtextbox";
            this.Fourthtextbox.ReadOnly = true;
            this.Fourthtextbox.Size = new System.Drawing.Size(100, 20);
            this.Fourthtextbox.TabIndex = 6;
            this.Fourthtextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(172, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(14, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "X";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(315, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(13, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "=";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(523, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Totals Combined";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(78, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "1st Number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(232, 72);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "2nd Number";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(381, 72);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Total";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 157);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Fourthtextbox);
            this.Controls.Add(this.Thirdtextbox);
            this.Controls.Add(this.Secondtextbox);
            this.Controls.Add(this.Firsttextbox);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.CalculatebButton);
            this.Name = "Form1";
            this.Text = "MultiAndAccum";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CalculatebButton;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.TextBox Firsttextbox;
        private System.Windows.Forms.TextBox Secondtextbox;
        private System.Windows.Forms.TextBox Thirdtextbox;
        private System.Windows.Forms.TextBox Fourthtextbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}

