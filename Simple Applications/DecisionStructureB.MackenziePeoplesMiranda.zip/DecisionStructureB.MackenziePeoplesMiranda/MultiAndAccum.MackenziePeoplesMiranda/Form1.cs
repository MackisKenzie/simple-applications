﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Author:MackenziePeoplesMiranda
//ID:
//Date: 7/2/23
//The goal of this program is to multiply the numbers and the add the results up for a total


namespace MultiAndAccum.MackenziePeoplesMiranda
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        //Variable to store the total of all results
        decimal totalresults = 0;


        private void CalculatebButton_Click(object sender, EventArgs e)
        {

            //Variables

            decimal box1 = 0;
            decimal box2 = 0;
            decimal box3 = 0;
            decimal box4 = 0;


            //
            // the validation
            if(decimal.TryParse(Firsttextbox.Text, out box1))
            {


                if(decimal.TryParse(Secondtextbox.Text, out box2))
                {

                }
                else
                {

                    // if wrong format is entered in the second box
                    MessageBox.Show("Error must be in nemeric format 0-9");
                    Secondtextbox.Focus();
                    Secondtextbox.Clear();
                    return;
                }
            }
            else
            {
                // if wrong format is entered in the first box
                MessageBox.Show("ERROR must be in numeric format 0-9");
                Firsttextbox.Focus();
                Firsttextbox.Clear();
                return;
            }


            //INPUT


            box1 = decimal.Parse(Firsttextbox.Text);
            box2 = decimal.Parse(Secondtextbox.Text);



            //PROCESSING
            //
            // the formulas for calculating whats the output
            box3 = box1 * box2;
            totalresults = box3 + totalresults;
            box4 = totalresults;















            //OUTPUT
            //
            // displays the results to the textboxes

            Thirdtextbox.Text = box3.ToString();
            Fourthtextbox.Text = box4.ToString();

            // changes color based on results
            if (box4 <= 0)
            {
                Fourthtextbox.BackColor = Color.Orange;
            }
            else if (box4 > 0)
            {
                Fourthtextbox.BackColor = Color.LightBlue;
            }






        }

        private void ClearButton_Click(object sender, EventArgs e)
        {

            //this resets all variables back to 0
            Firsttextbox.Text = "";
            Secondtextbox.Text = "";
            Thirdtextbox.Text = "";
            Fourthtextbox.Text = "";
            Fourthtextbox.BackColor = Color.Empty;
            totalresults = 0;

        }

        private void ExitButton_Click(object sender, EventArgs e)
        {

            // Closes the application
            Close();



        }
    }
}
