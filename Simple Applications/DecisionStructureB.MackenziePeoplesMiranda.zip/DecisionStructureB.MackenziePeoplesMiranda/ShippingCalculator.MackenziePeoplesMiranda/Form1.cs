﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.CompilerServices;
using System.Runtime.ConstrainedExecution;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Author: Mackenzie Peoples Miranda
//ID:
//Date: 7/2/23
//The goal of this program is to calculate shipping costs with a cap of $100.00


namespace ShippingCalculator.MackenziePeoplesMiranda
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void button1_Click(object sender, EventArgs e)
        {


            //variables
            //
            //
            decimal itemw;
            string zonecost = Zonetextbox.Text;
            decimal totalshippingcost;
            decimal weightcost;
          
            


            //Processing
            //
            //
            if (decimal.TryParse(ItemWeighttextbox.Text, out itemw))
            {


            }
            else
            {

                // when the wrong format is used in the weight textbox
                MessageBox.Show("ERROR must be in numeric format 0-9");
                ItemWeighttextbox.Focus();
                ItemWeighttextbox.Clear();
                return;
            }

            // varables containing simple formulas
            weightcost = itemw * 18;
            totalshippingcost = 18 * itemw;


            // switch method for the zone selection
            switch (zonecost)
            {
                case "N" :
                    Zonecosttextbox.Text = "$27.00";
                    break;
                case "E":
                    Zonecosttextbox.Text = "$45.00";
                    break;
                case "S":
                    Zonecosttextbox.Text = "$36.00";
                    break;
                case "W":
                    Zonecosttextbox.Text = "$54.00";
                    break;
            }

            if (zonecost == "N")
            {
                totalshippingcost = totalshippingcost + 27;
            }
            else if (zonecost == "E")
            {
                totalshippingcost = totalshippingcost + 45;
            }
            else if (zonecost == "S")
            {
                totalshippingcost = totalshippingcost + 36;
            }
            else if (zonecost == "W")
            {
                totalshippingcost = totalshippingcost + 54;
            }
            else
            {

                // when the wrong letter is entered this message will pop up
                MessageBox.Show("ERROR must be a correct zone letter N,E,S,W");
                Zonetextbox.Focus();
                Zonetextbox.Clear();
                return;
            }
            
            // event for when the total reaches 100 or higher
            if (totalshippingcost >= 100)
            {
                totalshippingcost = totalshippingcost - totalshippingcost +100;
                Cappedlabel.Text = "CAPPED";
                Cappedlabel.ForeColor = Color.Red;
            }























            //OUTPUT
            //
            Weightcosttextbox.Text = weightcost.ToString("c");
            Totalshippingcosttextbox.Text= totalshippingcost.ToString("c");

            // clears the user's inputs after calaculate is clicked
            ItemWeighttextbox.Text = "";
            Zonetextbox.Text = "";






        }

        private void button2_Click(object sender, EventArgs e)
        {

            // clears all values entered
            ItemWeighttextbox.Text = "";
            Weightcosttextbox.Text = "";
            Totalshippingcosttextbox.Text = "";
            Zonecosttextbox.Text = "";
            Zonetextbox.Text = "";
            Cappedlabel.Text = "";
            Cappedlabel.ForeColor = Color.Empty;


        }

        private void button3_Click(object sender, EventArgs e)
        {
            //closes the application

            Close();
        }

        private void button4_Click(object sender, EventArgs e)

            //button for explaining the zone costs
        {
            MessageBox.Show("$18.00 PER POUND ‘weight cost’ PLUS: \r\n $27.00 ‘zone cost’ FLAT surcharge if shipped to zone N\r\n $36.00 ‘zone cost’ FLAT surcharge if shipped to zone S\r\n $45.00 ‘zone cost’ FLAT surcharge if shipped to zone E\r\n $54.00 ‘zone cost’ FLAT surcharge if shipped to zone W");
        }
    }
}
