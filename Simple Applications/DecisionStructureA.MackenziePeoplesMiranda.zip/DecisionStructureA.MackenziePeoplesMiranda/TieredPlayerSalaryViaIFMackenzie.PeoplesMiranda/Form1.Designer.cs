﻿namespace TieredPlayerSalaryViaIFMackenzie.PeoplesMiranda
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Player1MVPcheckbox = new System.Windows.Forms.CheckBox();
            this.Player1ALLSTARcheckbox = new System.Windows.Forms.CheckBox();
            this.Player1hits = new System.Windows.Forms.TextBox();
            this.Player1name = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Player2MVPcheckbox = new System.Windows.Forms.CheckBox();
            this.Player2ALLSTARcheckbox = new System.Windows.Forms.CheckBox();
            this.Player2hits = new System.Windows.Forms.TextBox();
            this.Player2name = new System.Windows.Forms.TextBox();
            this.Calculatebutton = new System.Windows.Forms.Button();
            this.Clearbutton = new System.Windows.Forms.Button();
            this.Exitbutton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.Player1MVPcheckbox);
            this.groupBox1.Controls.Add(this.Player1ALLSTARcheckbox);
            this.groupBox1.Controls.Add(this.Player1hits);
            this.groupBox1.Controls.Add(this.Player1name);
            this.groupBox1.Location = new System.Drawing.Point(12, 94);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(304, 140);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Player 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(59, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Enter # of hits";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Enter player\'s name";
            // 
            // Player1MVPcheckbox
            // 
            this.Player1MVPcheckbox.AutoSize = true;
            this.Player1MVPcheckbox.Location = new System.Drawing.Point(205, 117);
            this.Player1MVPcheckbox.Name = "Player1MVPcheckbox";
            this.Player1MVPcheckbox.Size = new System.Drawing.Size(49, 17);
            this.Player1MVPcheckbox.TabIndex = 10;
            this.Player1MVPcheckbox.Text = "MVP";
            this.Player1MVPcheckbox.UseVisualStyleBackColor = true;
            // 
            // Player1ALLSTARcheckbox
            // 
            this.Player1ALLSTARcheckbox.AutoSize = true;
            this.Player1ALLSTARcheckbox.Location = new System.Drawing.Point(177, 87);
            this.Player1ALLSTARcheckbox.Name = "Player1ALLSTARcheckbox";
            this.Player1ALLSTARcheckbox.Size = new System.Drawing.Size(77, 17);
            this.Player1ALLSTARcheckbox.TabIndex = 4;
            this.Player1ALLSTARcheckbox.Text = "ALL-STAR";
            this.Player1ALLSTARcheckbox.UseVisualStyleBackColor = true;
            // 
            // Player1hits
            // 
            this.Player1hits.Location = new System.Drawing.Point(154, 61);
            this.Player1hits.Name = "Player1hits";
            this.Player1hits.Size = new System.Drawing.Size(100, 20);
            this.Player1hits.TabIndex = 5;
            // 
            // Player1name
            // 
            this.Player1name.Location = new System.Drawing.Point(154, 19);
            this.Player1name.Name = "Player1name";
            this.Player1name.Size = new System.Drawing.Size(100, 20);
            this.Player1name.TabIndex = 4;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.Player2MVPcheckbox);
            this.groupBox2.Controls.Add(this.Player2ALLSTARcheckbox);
            this.groupBox2.Controls.Add(this.Player2hits);
            this.groupBox2.Controls.Add(this.Player2name);
            this.groupBox2.Location = new System.Drawing.Point(445, 94);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(304, 140);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Player 2";
            // 
            // Player2MVPcheckbox
            // 
            this.Player2MVPcheckbox.AutoSize = true;
            this.Player2MVPcheckbox.Location = new System.Drawing.Point(158, 110);
            this.Player2MVPcheckbox.Name = "Player2MVPcheckbox";
            this.Player2MVPcheckbox.Size = new System.Drawing.Size(49, 17);
            this.Player2MVPcheckbox.TabIndex = 9;
            this.Player2MVPcheckbox.Text = "MVP";
            this.Player2MVPcheckbox.UseVisualStyleBackColor = true;
            // 
            // Player2ALLSTARcheckbox
            // 
            this.Player2ALLSTARcheckbox.AutoSize = true;
            this.Player2ALLSTARcheckbox.Location = new System.Drawing.Point(158, 87);
            this.Player2ALLSTARcheckbox.Name = "Player2ALLSTARcheckbox";
            this.Player2ALLSTARcheckbox.Size = new System.Drawing.Size(77, 17);
            this.Player2ALLSTARcheckbox.TabIndex = 8;
            this.Player2ALLSTARcheckbox.Text = "ALL-STAR";
            this.Player2ALLSTARcheckbox.UseVisualStyleBackColor = true;
            // 
            // Player2hits
            // 
            this.Player2hits.Location = new System.Drawing.Point(158, 61);
            this.Player2hits.Name = "Player2hits";
            this.Player2hits.Size = new System.Drawing.Size(100, 20);
            this.Player2hits.TabIndex = 7;
            // 
            // Player2name
            // 
            this.Player2name.Location = new System.Drawing.Point(158, 19);
            this.Player2name.Name = "Player2name";
            this.Player2name.Size = new System.Drawing.Size(100, 20);
            this.Player2name.TabIndex = 6;
            // 
            // Calculatebutton
            // 
            this.Calculatebutton.Location = new System.Drawing.Point(12, 255);
            this.Calculatebutton.Name = "Calculatebutton";
            this.Calculatebutton.Size = new System.Drawing.Size(226, 50);
            this.Calculatebutton.TabIndex = 1;
            this.Calculatebutton.Text = "Calculate";
            this.Calculatebutton.UseVisualStyleBackColor = true;
            this.Calculatebutton.Click += new System.EventHandler(this.Calculatebutton_Click);
            // 
            // Clearbutton
            // 
            this.Clearbutton.Location = new System.Drawing.Point(270, 255);
            this.Clearbutton.Name = "Clearbutton";
            this.Clearbutton.Size = new System.Drawing.Size(226, 50);
            this.Clearbutton.TabIndex = 2;
            this.Clearbutton.Text = "Clear";
            this.Clearbutton.UseVisualStyleBackColor = true;
            this.Clearbutton.Click += new System.EventHandler(this.Clearbutton_Click);
            // 
            // Exitbutton
            // 
            this.Exitbutton.Location = new System.Drawing.Point(523, 255);
            this.Exitbutton.Name = "Exitbutton";
            this.Exitbutton.Size = new System.Drawing.Size(226, 50);
            this.Exitbutton.TabIndex = 3;
            this.Exitbutton.Text = "Exit";
            this.Exitbutton.UseVisualStyleBackColor = true;
            this.Exitbutton.Click += new System.EventHandler(this.Exitbutton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Enter player\'s name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(64, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Enter # of hits";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(203, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(327, 53);
            this.label5.TabIndex = 4;
            this.label5.Text = "TieredPlayerSalary";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(761, 319);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Exitbutton);
            this.Controls.Add(this.Clearbutton);
            this.Controls.Add(this.Calculatebutton);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox Player1hits;
        private System.Windows.Forms.TextBox Player1name;
        private System.Windows.Forms.CheckBox Player2MVPcheckbox;
        private System.Windows.Forms.CheckBox Player2ALLSTARcheckbox;
        private System.Windows.Forms.TextBox Player2hits;
        private System.Windows.Forms.TextBox Player2name;
        private System.Windows.Forms.CheckBox Player1MVPcheckbox;
        private System.Windows.Forms.CheckBox Player1ALLSTARcheckbox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.Button Calculatebutton;
        public System.Windows.Forms.Button Clearbutton;
        public System.Windows.Forms.Button Exitbutton;
        private System.Windows.Forms.Label label5;
    }
}

