﻿namespace TieredPlayerSalaryViaIFMackenzie.PeoplesMiranda
{
    partial class Results
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.P1nm = new System.Windows.Forms.Label();
            this.P1s = new System.Windows.Forms.Label();
            this.P1t = new System.Windows.Forms.Label();
            this.P2nm = new System.Windows.Forms.Label();
            this.P2s = new System.Windows.Forms.Label();
            this.P2t = new System.Windows.Forms.Label();
            this.P1mvp = new System.Windows.Forms.Label();
            this.P2mvp = new System.Windows.Forms.Label();
            this.P1total = new System.Windows.Forms.Label();
            this.P2total = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(53, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Player 1 Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(71, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Salary";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(48, 169);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "MVP or ALLSTAR";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(71, 223);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Total";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(277, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Player 2 Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(297, 120);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Salary";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(272, 169);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "MVP or ALLSTAR";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(297, 223);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Total";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(144, 120);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(25, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "Tier";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(367, 120);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(25, 13);
            this.label10.TabIndex = 19;
            this.label10.Text = "Tier";
            // 
            // P1nm
            // 
            this.P1nm.AutoSize = true;
            this.P1nm.Location = new System.Drawing.Point(66, 85);
            this.P1nm.Name = "P1nm";
            this.P1nm.Size = new System.Drawing.Size(0, 13);
            this.P1nm.TabIndex = 20;
            // 
            // P1s
            // 
            this.P1s.AutoSize = true;
            this.P1s.Location = new System.Drawing.Point(66, 145);
            this.P1s.Name = "P1s";
            this.P1s.Size = new System.Drawing.Size(0, 13);
            this.P1s.TabIndex = 21;
            // 
            // P1t
            // 
            this.P1t.AutoSize = true;
            this.P1t.Location = new System.Drawing.Point(144, 133);
            this.P1t.Name = "P1t";
            this.P1t.Size = new System.Drawing.Size(0, 13);
            this.P1t.TabIndex = 22;
            // 
            // P2nm
            // 
            this.P2nm.AutoSize = true;
            this.P2nm.Location = new System.Drawing.Point(292, 85);
            this.P2nm.Name = "P2nm";
            this.P2nm.Size = new System.Drawing.Size(0, 13);
            this.P2nm.TabIndex = 23;
            // 
            // P2s
            // 
            this.P2s.AutoSize = true;
            this.P2s.Location = new System.Drawing.Point(292, 145);
            this.P2s.Name = "P2s";
            this.P2s.Size = new System.Drawing.Size(0, 13);
            this.P2s.TabIndex = 24;
            // 
            // P2t
            // 
            this.P2t.AutoSize = true;
            this.P2t.Location = new System.Drawing.Point(367, 133);
            this.P2t.Name = "P2t";
            this.P2t.Size = new System.Drawing.Size(0, 13);
            this.P2t.TabIndex = 25;
            // 
            // P1mvp
            // 
            this.P1mvp.AutoSize = true;
            this.P1mvp.Location = new System.Drawing.Point(66, 192);
            this.P1mvp.Name = "P1mvp";
            this.P1mvp.Size = new System.Drawing.Size(0, 13);
            this.P1mvp.TabIndex = 26;
            // 
            // P2mvp
            // 
            this.P2mvp.AutoSize = true;
            this.P2mvp.Location = new System.Drawing.Point(297, 192);
            this.P2mvp.Name = "P2mvp";
            this.P2mvp.Size = new System.Drawing.Size(0, 13);
            this.P2mvp.TabIndex = 27;
            // 
            // P1total
            // 
            this.P1total.AutoSize = true;
            this.P1total.Location = new System.Drawing.Point(66, 252);
            this.P1total.Name = "P1total";
            this.P1total.Size = new System.Drawing.Size(0, 13);
            this.P1total.TabIndex = 28;
            // 
            // P2total
            // 
            this.P2total.AutoSize = true;
            this.P2total.Location = new System.Drawing.Point(297, 252);
            this.P2total.Name = "P2total";
            this.P2total.Size = new System.Drawing.Size(0, 13);
            this.P2total.TabIndex = 29;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(190, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 13);
            this.label11.TabIndex = 30;
            this.label11.Text = "Results";
            // 
            // Results
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(454, 274);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.P2total);
            this.Controls.Add(this.P1total);
            this.Controls.Add(this.P2mvp);
            this.Controls.Add(this.P1mvp);
            this.Controls.Add(this.P2t);
            this.Controls.Add(this.P2s);
            this.Controls.Add(this.P2nm);
            this.Controls.Add(this.P1t);
            this.Controls.Add(this.P1s);
            this.Controls.Add(this.P1nm);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Results";
            this.Text = "Results";
            this.Load += new System.EventHandler(this.Results_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label label7;
        public System.Windows.Forms.Label label8;
        public System.Windows.Forms.Label label9;
        public System.Windows.Forms.Label label10;
        public System.Windows.Forms.Label P1nm;
        public System.Windows.Forms.Label P1s;
        public System.Windows.Forms.Label P1t;
        public System.Windows.Forms.Label P2nm;
        public System.Windows.Forms.Label P2s;
        public System.Windows.Forms.Label P2t;
        public System.Windows.Forms.Label P1mvp;
        public System.Windows.Forms.Label P2mvp;
        public System.Windows.Forms.Label P1total;
        public System.Windows.Forms.Label P2total;
        private System.Windows.Forms.Label label11;
    }
}