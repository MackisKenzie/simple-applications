﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TieredPlayerSalaryViaIFMackenzie.PeoplesMiranda
{
    public partial class Results : Form
    {

        // variables
        public string p1nm {  get; set; }
        public string p2nm { get; set; }
        public decimal p1s { get; set; }
        public decimal p2s { get; set; }
        public decimal p1t { get; set; }
        public decimal p2t { get; set; }
        public decimal p1mvp { get; set; }
        public decimal p2mvp { get; set; }



        
        public Results()
        {
            InitializeComponent();
        }

        private void Results_Load(object sender, EventArgs e)
        {
            // inputs
            decimal total1;
            decimal total2;

            // processing
            total1 = p1s + p1mvp;
            total2 = p2s + p2mvp;

            // displays results
            P1nm.Text = p1nm;
            P1mvp.Text = p1mvp.ToString("c");
            P1s.Text = p1s.ToString("c");
            P1t.Text = p1t.ToString();
            P2nm.Text = p2nm;
            P2mvp.Text = p2mvp.ToString("c");
            P2s.Text = p2s.ToString("c");
            P2t.Text = p2t.ToString();
            P1total.Text = total1.ToString("c");
            P2total.Text = total2.ToString("c");
        }


        

        }
    }
    

