﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Author: Mackenzie Peoples Miranda
//ID: Your Student ID Number (NOT YOUR SOCIAL SECURITY NUMBER) 
//Date: 
//Goal of this program is to calculate salaries based on user's input

namespace TieredPlayerSalaryViaIFMackenzie.PeoplesMiranda
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // variables for the tier system
        const decimal consttier1 = 17500;
        const decimal consttier2 = 20000;
        const decimal consttier3 = 22500;
        const decimal consttier4 = 25000;
        



        public void Calculatebutton_Click(object sender, EventArgs e)
        {

            
            // variables
            Results results = new Results();
            decimal player1hits = 0;
            decimal player2hits = 0;

            int calcTier = 0;
            int calcTier2 = 0;

            decimal calcplayer1hits = 0;
            decimal calcplayer2hits = 0;
            decimal calcp1mvp = 0;
            decimal calcp2mvp = 0;

            // inputs 
                
            decimal.TryParse(Player1hits.Text, out player1hits);
            decimal.TryParse(Player2hits.Text, out player2hits);

            // if method to determine payscale per hit for player 1
            if (player1hits <= 49)
            {
                calcplayer1hits = player1hits * consttier1;
                
            }
            else if (player1hits <= 99)
            { 
                calcplayer1hits = player1hits * consttier2;
            }
            else if (player1hits <= 149)
            { 
               calcplayer1hits = player1hits * consttier3; 
            }
            else if (player1hits > 150)
            {
              calcplayer1hits = player1hits * consttier4;
            }

            // if method to determine wich boxes are checked
            if (Player1MVPcheckbox.Checked) 
            {
                calcp1mvp = calcplayer1hits * 0.20m;
            }
            else if (Player1ALLSTARcheckbox.Checked)
            {
                calcp1mvp = calcplayer1hits * 0.20m;
            }
            if (Player1ALLSTARcheckbox.Checked && Player1MVPcheckbox.Checked)
            {
               calcp1mvp = calcplayer1hits * 0.25m;
            }


            // if method to determine what tier player one is in
            if (player1hits <= 49)
            {
                calcTier = 1;
            }
            else if (player1hits <= 99)
            {
                calcTier = 2;
            }
            else if (player1hits <= 149)
            {
                calcTier = 3;
            }
            else if (player1hits >= 150)
            {
                calcTier = 4;
            }


            // if method to determine payscale for player 2
            if (player2hits <= 49)
            {
                calcplayer2hits = player2hits * consttier1;
            }
            else if (player2hits <= 99)
            {
                calcplayer2hits = player2hits * consttier2;
            }
            else if (player2hits <= 149)
            {
                calcplayer2hits = player2hits * consttier3;
            }
            else if (player2hits >= 150)
            {
                calcplayer2hits = player2hits * consttier4;
            }


            // if method to determine which boxes are checked for player 2
            if (Player2MVPcheckbox.Checked)
            {
                calcp2mvp = calcplayer2hits * 0.20m;
            }
            else if (Player2ALLSTARcheckbox.Checked)
            {
                calcp2mvp = calcplayer2hits * 0.20m;
            }
            if (Player2ALLSTARcheckbox.Checked && Player2MVPcheckbox.Checked)
            {
                calcp2mvp = calcplayer2hits * 0.25m;
            }

            // if method to determine which tier player 2 is on

            if (player2hits <= 49)
            {
                calcTier2 = 1;
            }
            else if (player2hits <= 99)
            {
                calcTier2 = 2;
            }
            else if (player2hits <= 149)
            { 
                calcTier2 = 3;
            }
            else if (player2hits >= 150)
            { 
                calcTier2 = 4;
            }

            // public variables to display on the next form
            results.p1nm = Player1name.Text;
            results.p2nm = Player2name.Text;
            results.p1t = calcTier;
            results.p2t = calcTier2;
            results.p1s = calcplayer1hits;
            results.p2s = calcplayer2hits;
            results.p1mvp = calcp1mvp;
            results.p2mvp = calcp2mvp;
            
            results.ShowDialog();

            
        }

        private void Clearbutton_Click(object sender, EventArgs e)
        {

            // clears all entries
            Player1ALLSTARcheckbox.Checked = false;
            Player2ALLSTARcheckbox.Checked = false;
            Player1MVPcheckbox.Checked = false;
            Player2MVPcheckbox.Checked = false;
            Player1name.Text = "";
            Player2name.Text = "";
            Player1hits.Text = "";
            Player2hits.Text = "";
           
        }

        private void Exitbutton_Click(object sender, EventArgs e)
        {

            // closes the application
            Close();

        }
    }
}
