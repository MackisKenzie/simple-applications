﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Author: Mackenzie Peoples Miranda
//ID:
//Date: 6/28/2023
//The goal of this program is to execute formulas to determine
// the diameter, circumference, and area of a circle


namespace MathLibCircleInfoMackenziePeoplesMiranda
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Calculatebutton_Click(object sender, EventArgs e)
        {
            try
            {


                // input
                double radius = Convert.ToDouble(Radiustextbox.Text);


       
                //processing
                //determines the diameter
                double diameter = Convert.ToDouble(radius * 2);

                //determines the circumference
                double circumference = Convert.ToDouble(2* Math.PI * radius);


                // determines the area
                double Area = Math.PI * Math.Pow(radius, 2);

                // output
                // displays the results
                Diametertextbox.Text = diameter.ToString("n2");
                Circumtextbox.Text = circumference.ToString("n2");
                Areatextbox.Text = Area.ToString("n2");


            }
            catch (Exception)
            {

                // tells the application to show a message box when wrong kind of format is used
                MessageBox.Show("Wrong format must be in numerical 0-9");



                throw;


            }
        }

        private void Clearbutton_Click(object sender, EventArgs e)
        {

            // clears all texboxes
            Radiustextbox.Text = "";
            Diametertextbox.Text = "";
            Circumtextbox.Text = "";
            Areatextbox.Text = "";

        }

        private void Exitbutton_Click(object sender, EventArgs e)
        {

            // closes the apllication
            Close();
        }
    }
}
