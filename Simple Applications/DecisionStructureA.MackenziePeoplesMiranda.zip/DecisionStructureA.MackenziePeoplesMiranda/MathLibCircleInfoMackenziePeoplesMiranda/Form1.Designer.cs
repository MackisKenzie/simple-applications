﻿namespace MathLibCircleInfoMackenziePeoplesMiranda
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Calculatebutton = new System.Windows.Forms.Button();
            this.Clearbutton = new System.Windows.Forms.Button();
            this.Exitbutton = new System.Windows.Forms.Button();
            this.Diametertextbox = new System.Windows.Forms.TextBox();
            this.Circumtextbox = new System.Windows.Forms.TextBox();
            this.Areatextbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Arealabel = new System.Windows.Forms.Label();
            this.Radiustextbox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Calculatebutton
            // 
            this.Calculatebutton.Location = new System.Drawing.Point(84, 317);
            this.Calculatebutton.Name = "Calculatebutton";
            this.Calculatebutton.Size = new System.Drawing.Size(75, 23);
            this.Calculatebutton.TabIndex = 0;
            this.Calculatebutton.Text = "Calculate";
            this.Calculatebutton.UseVisualStyleBackColor = true;
            this.Calculatebutton.Click += new System.EventHandler(this.Calculatebutton_Click);
            // 
            // Clearbutton
            // 
            this.Clearbutton.Location = new System.Drawing.Point(192, 317);
            this.Clearbutton.Name = "Clearbutton";
            this.Clearbutton.Size = new System.Drawing.Size(75, 23);
            this.Clearbutton.TabIndex = 1;
            this.Clearbutton.Text = "Clear";
            this.Clearbutton.UseVisualStyleBackColor = true;
            this.Clearbutton.Click += new System.EventHandler(this.Clearbutton_Click);
            // 
            // Exitbutton
            // 
            this.Exitbutton.Location = new System.Drawing.Point(299, 317);
            this.Exitbutton.Name = "Exitbutton";
            this.Exitbutton.Size = new System.Drawing.Size(75, 23);
            this.Exitbutton.TabIndex = 2;
            this.Exitbutton.Text = "Exit";
            this.Exitbutton.UseVisualStyleBackColor = true;
            this.Exitbutton.Click += new System.EventHandler(this.Exitbutton_Click);
            // 
            // Diametertextbox
            // 
            this.Diametertextbox.Location = new System.Drawing.Point(178, 136);
            this.Diametertextbox.Name = "Diametertextbox";
            this.Diametertextbox.ReadOnly = true;
            this.Diametertextbox.Size = new System.Drawing.Size(100, 20);
            this.Diametertextbox.TabIndex = 3;
            this.Diametertextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Circumtextbox
            // 
            this.Circumtextbox.Location = new System.Drawing.Point(178, 188);
            this.Circumtextbox.Name = "Circumtextbox";
            this.Circumtextbox.ReadOnly = true;
            this.Circumtextbox.Size = new System.Drawing.Size(100, 20);
            this.Circumtextbox.TabIndex = 4;
            this.Circumtextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Areatextbox
            // 
            this.Areatextbox.Location = new System.Drawing.Point(178, 242);
            this.Areatextbox.Name = "Areatextbox";
            this.Areatextbox.ReadOnly = true;
            this.Areatextbox.Size = new System.Drawing.Size(100, 20);
            this.Areatextbox.TabIndex = 5;
            this.Areatextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(110, 136);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Diameter";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(97, 188);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Circumference";
            // 
            // Arealabel
            // 
            this.Arealabel.AutoSize = true;
            this.Arealabel.Location = new System.Drawing.Point(124, 242);
            this.Arealabel.Name = "Arealabel";
            this.Arealabel.Size = new System.Drawing.Size(29, 13);
            this.Arealabel.TabIndex = 8;
            this.Arealabel.Text = "Area";
            // 
            // Radiustextbox
            // 
            this.Radiustextbox.Location = new System.Drawing.Point(178, 58);
            this.Radiustextbox.Name = "Radiustextbox";
            this.Radiustextbox.Size = new System.Drawing.Size(100, 20);
            this.Radiustextbox.TabIndex = 9;
            this.Radiustextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(141, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(173, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Please enter the radius of the circle";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(460, 405);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Radiustextbox);
            this.Controls.Add(this.Arealabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Areatextbox);
            this.Controls.Add(this.Circumtextbox);
            this.Controls.Add(this.Diametertextbox);
            this.Controls.Add(this.Exitbutton);
            this.Controls.Add(this.Clearbutton);
            this.Controls.Add(this.Calculatebutton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Calculatebutton;
        private System.Windows.Forms.Button Clearbutton;
        private System.Windows.Forms.Button Exitbutton;
        private System.Windows.Forms.TextBox Diametertextbox;
        private System.Windows.Forms.TextBox Circumtextbox;
        private System.Windows.Forms.TextBox Areatextbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Arealabel;
        private System.Windows.Forms.TextBox Radiustextbox;
        private System.Windows.Forms.Label label4;
    }
}

