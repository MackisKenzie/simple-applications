﻿namespace UIControlsAndMultiLine.MackenziePeoplesMiranda
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.CalculateButton = new System.Windows.Forms.Button();
            this.ClearallButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.TotalcostTextbox = new System.Windows.Forms.TextBox();
            this.OrderTextbox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Chevyradiobutton = new System.Windows.Forms.RadioButton();
            this.HondaRadiobutton = new System.Windows.Forms.RadioButton();
            this.RemotestarterCheckbox = new System.Windows.Forms.CheckBox();
            this.WifiCheckbox = new System.Windows.Forms.CheckBox();
            this.RearcamCheckbox = new System.Windows.Forms.CheckBox();
            this.TintedwindowsCheckbox = new System.Windows.Forms.CheckBox();
            this.DashcamCheckbox = new System.Windows.Forms.CheckBox();
            this.DvdplayerCheckbox = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(625, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "This aplication will show the total cost of selected care and selected options. I" +
    "t will also display the text describing what was chosen";
            // 
            // CalculateButton
            // 
            this.CalculateButton.Location = new System.Drawing.Point(359, 64);
            this.CalculateButton.Name = "CalculateButton";
            this.CalculateButton.Size = new System.Drawing.Size(128, 26);
            this.CalculateButton.TabIndex = 1;
            this.CalculateButton.Text = "Calculate";
            this.CalculateButton.UseVisualStyleBackColor = true;
            this.CalculateButton.Click += new System.EventHandler(this.CalculateButton_Click);
            // 
            // ClearallButton
            // 
            this.ClearallButton.Location = new System.Drawing.Point(541, 66);
            this.ClearallButton.Name = "ClearallButton";
            this.ClearallButton.Size = new System.Drawing.Size(75, 23);
            this.ClearallButton.TabIndex = 2;
            this.ClearallButton.Text = "Clear All";
            this.ClearallButton.UseVisualStyleBackColor = true;
            this.ClearallButton.Click += new System.EventHandler(this.ClearallButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.HondaRadiobutton);
            this.groupBox1.Controls.Add(this.Chevyradiobutton);
            this.groupBox1.Location = new System.Drawing.Point(15, 76);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(286, 73);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Choose one car to buy";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.DvdplayerCheckbox);
            this.groupBox2.Controls.Add(this.DashcamCheckbox);
            this.groupBox2.Controls.Add(this.TintedwindowsCheckbox);
            this.groupBox2.Controls.Add(this.RearcamCheckbox);
            this.groupBox2.Controls.Add(this.WifiCheckbox);
            this.groupBox2.Controls.Add(this.RemotestarterCheckbox);
            this.groupBox2.Location = new System.Drawing.Point(15, 184);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(306, 142);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Choose one or more optional features";
            // 
            // TotalcostTextbox
            // 
            this.TotalcostTextbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalcostTextbox.Location = new System.Drawing.Point(471, 140);
            this.TotalcostTextbox.Name = "TotalcostTextbox";
            this.TotalcostTextbox.ReadOnly = true;
            this.TotalcostTextbox.Size = new System.Drawing.Size(166, 20);
            this.TotalcostTextbox.TabIndex = 4;
            // 
            // OrderTextbox
            // 
            this.OrderTextbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OrderTextbox.Location = new System.Drawing.Point(359, 205);
            this.OrderTextbox.Multiline = true;
            this.OrderTextbox.Name = "OrderTextbox";
            this.OrderTextbox.ReadOnly = true;
            this.OrderTextbox.Size = new System.Drawing.Size(283, 121);
            this.OrderTextbox.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(313, 143);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Total Cost of car and options $";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(356, 189);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(187, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "What you Ordered (Use \\n line breaks";
            // 
            // Chevyradiobutton
            // 
            this.Chevyradiobutton.AutoSize = true;
            this.Chevyradiobutton.Location = new System.Drawing.Point(52, 19);
            this.Chevyradiobutton.Name = "Chevyradiobutton";
            this.Chevyradiobutton.Size = new System.Drawing.Size(188, 17);
            this.Chevyradiobutton.TabIndex = 8;
            this.Chevyradiobutton.TabStop = true;
            this.Chevyradiobutton.Text = "2023 Chevrolet Corvette ($64,500)";
            this.Chevyradiobutton.UseVisualStyleBackColor = true;
            // 
            // HondaRadiobutton
            // 
            this.HondaRadiobutton.AutoSize = true;
            this.HondaRadiobutton.Location = new System.Drawing.Point(52, 50);
            this.HondaRadiobutton.Name = "HondaRadiobutton";
            this.HondaRadiobutton.Size = new System.Drawing.Size(158, 17);
            this.HondaRadiobutton.TabIndex = 9;
            this.HondaRadiobutton.TabStop = true;
            this.HondaRadiobutton.Text = "2023 Honda Civic ($23,750)";
            this.HondaRadiobutton.UseVisualStyleBackColor = true;
            // 
            // RemotestarterCheckbox
            // 
            this.RemotestarterCheckbox.AutoSize = true;
            this.RemotestarterCheckbox.Location = new System.Drawing.Point(15, 22);
            this.RemotestarterCheckbox.Name = "RemotestarterCheckbox";
            this.RemotestarterCheckbox.Size = new System.Drawing.Size(137, 17);
            this.RemotestarterCheckbox.TabIndex = 10;
            this.RemotestarterCheckbox.Text = "Remote starter ($1,500)";
            this.RemotestarterCheckbox.UseVisualStyleBackColor = true;
            // 
            // WifiCheckbox
            // 
            this.WifiCheckbox.AutoSize = true;
            this.WifiCheckbox.Location = new System.Drawing.Point(15, 58);
            this.WifiCheckbox.Name = "WifiCheckbox";
            this.WifiCheckbox.Size = new System.Drawing.Size(77, 17);
            this.WifiCheckbox.TabIndex = 11;
            this.WifiCheckbox.Text = "Wifi ($350)";
            this.WifiCheckbox.UseVisualStyleBackColor = true;
            // 
            // RearcamCheckbox
            // 
            this.RearcamCheckbox.AutoSize = true;
            this.RearcamCheckbox.Location = new System.Drawing.Point(15, 96);
            this.RearcamCheckbox.Name = "RearcamCheckbox";
            this.RearcamCheckbox.Size = new System.Drawing.Size(127, 17);
            this.RearcamCheckbox.TabIndex = 12;
            this.RearcamCheckbox.Text = "Rear Camera ($1000)";
            this.RearcamCheckbox.UseVisualStyleBackColor = true;
            // 
            // TintedwindowsCheckbox
            // 
            this.TintedwindowsCheckbox.AutoSize = true;
            this.TintedwindowsCheckbox.Location = new System.Drawing.Point(164, 22);
            this.TintedwindowsCheckbox.Name = "TintedwindowsCheckbox";
            this.TintedwindowsCheckbox.Size = new System.Drawing.Size(136, 17);
            this.TintedwindowsCheckbox.TabIndex = 13;
            this.TintedwindowsCheckbox.Text = "Tinted Windows ($875)";
            this.TintedwindowsCheckbox.UseVisualStyleBackColor = true;
            // 
            // DashcamCheckbox
            // 
            this.DashcamCheckbox.AutoSize = true;
            this.DashcamCheckbox.Location = new System.Drawing.Point(164, 58);
            this.DashcamCheckbox.Name = "DashcamCheckbox";
            this.DashcamCheckbox.Size = new System.Drawing.Size(108, 17);
            this.DashcamCheckbox.TabIndex = 14;
            this.DashcamCheckbox.Text = "Dash Cam ($250)";
            this.DashcamCheckbox.UseVisualStyleBackColor = true;
            // 
            // DvdplayerCheckbox
            // 
            this.DvdplayerCheckbox.AutoSize = true;
            this.DvdplayerCheckbox.Location = new System.Drawing.Point(164, 96);
            this.DvdplayerCheckbox.Name = "DvdplayerCheckbox";
            this.DvdplayerCheckbox.Size = new System.Drawing.Size(114, 17);
            this.DvdplayerCheckbox.TabIndex = 15;
            this.DvdplayerCheckbox.Text = "DVD Player ($500)";
            this.DvdplayerCheckbox.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 347);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.OrderTextbox);
            this.Controls.Add(this.TotalcostTextbox);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.ClearallButton);
            this.Controls.Add(this.CalculateButton);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "UIControlsAndMultiLine";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button CalculateButton;
        private System.Windows.Forms.Button ClearallButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox TotalcostTextbox;
        private System.Windows.Forms.TextBox OrderTextbox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton HondaRadiobutton;
        private System.Windows.Forms.RadioButton Chevyradiobutton;
        private System.Windows.Forms.CheckBox DashcamCheckbox;
        private System.Windows.Forms.CheckBox TintedwindowsCheckbox;
        private System.Windows.Forms.CheckBox RearcamCheckbox;
        private System.Windows.Forms.CheckBox WifiCheckbox;
        private System.Windows.Forms.CheckBox RemotestarterCheckbox;
        private System.Windows.Forms.CheckBox DvdplayerCheckbox;
    }
}

