﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Author:Mackenzie Peoples Miranda
//ID:
//Date: 7/9/23
//The goal of this program is to create a list depending on is selected and added together

namespace UIControlsAndMultiLine.MackenziePeoplesMiranda
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


        }

        
        private void CalculateButton_Click(object sender, EventArgs e)
        {

            // variables
            decimal total = 0;

            // if method for which car is selected
            if (Chevyradiobutton.Checked == HondaRadiobutton.Checked)
            {
                MessageBox.Show("must pick a car"); // if not car is selected an error will appear and return
                return;
            }
            if (Chevyradiobutton.Checked)
            {
                OrderTextbox.Text = ("2023 Chevrolet Corvette ($64,500)");
                total = total + 64500;
                TotalcostTextbox.Text = total.ToString("c");

            }
            if (HondaRadiobutton.Checked)
            {
                OrderTextbox.Text = ("2023 Honda Civic ($23,750)");
                total = total + 23750;
                TotalcostTextbox.Text = total.ToString("c");
            }
            //adds text to textbox
            // adds totals together
            // output
            // all of the checkboxes and what to add
            // depending on what is clicked
            if (RemotestarterCheckbox.Checked)
            {
                OrderTextbox.Text = OrderTextbox.Text + " \r\n" + "Remote Starter ($1,500)"; //adds text to textbox
                total = total + 1500;                                                       // adds totals together
                TotalcostTextbox.Text = total.ToString("c");                               // output

            }
            if (WifiCheckbox.Checked)
            {
                OrderTextbox.Text = OrderTextbox.Text + " \r\n" + "Wifi ($350)";//adds text to textbox
                total = total + 350;                                                      // adds totals together
                TotalcostTextbox.Text = total.ToString("c");                          // output

            }
            if (RearcamCheckbox.Checked)
            {
                OrderTextbox.Text = OrderTextbox.Text + " \r\n" + "Rear Camera ($1000)";            
                total = total + 1000;
                TotalcostTextbox.Text = total.ToString("c");

            }
            if (TintedwindowsCheckbox.Checked)
            {
                OrderTextbox.Text = OrderTextbox.Text + " \r\n" + "Tinted Windows ($875)";
                total = total + 875;
                TotalcostTextbox.Text = total.ToString("c");

            }
            if (DashcamCheckbox.Checked)
            {
                OrderTextbox.Text = OrderTextbox.Text + " \r\n" + "Dashboard Camera ($250)";
                total = total + 250;
                TotalcostTextbox.Text = total.ToString("c");

            }
            if (DvdplayerCheckbox.Checked)
            {
                OrderTextbox.Text = OrderTextbox.Text + " \r\n" + "DVD Player ($500";
                total = total + 500;
                TotalcostTextbox.Text = total.ToString("c");

            }

            // if method when no optional features are selected
            if (DvdplayerCheckbox.Checked==false && DashcamCheckbox.Checked==false && TintedwindowsCheckbox.Checked==false && RearcamCheckbox.Checked==false
                && WifiCheckbox.Checked==false && RemotestarterCheckbox.Checked==false)
            {
                OrderTextbox.Text = OrderTextbox.Text + " \r\n" + "No Optional Features Selected";
                total = total;
                TotalcostTextbox.Text = total.ToString("c");

            }





            }

        private void ClearallButton_Click(object sender, EventArgs e)
        {

            // clears all values from the aplication
            Chevyradiobutton.Checked = false;

            Chevyradiobutton.Checked = false;

            HondaRadiobutton.Checked = false;

            RemotestarterCheckbox.Checked = false;

            WifiCheckbox.Checked = false;

            RearcamCheckbox.Checked = false;

            TintedwindowsCheckbox.Checked = false;

            DashcamCheckbox.Checked = false;

            DvdplayerCheckbox.Checked = false;

            TotalcostTextbox.Text = "";

            OrderTextbox.Text = "";








        }
    }
    }

